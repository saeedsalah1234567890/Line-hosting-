import { useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { CheckCircle, Loader2 } from 'lucide-react'

const AuthSuccess = () => {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()

  useEffect(() => {
    const token = searchParams.get('token')
    
    if (token) {
      // حفظ التوكن في localStorage
      localStorage.setItem('token', token)
      
      // إعادة توجيه المستخدم بعد ثانيتين
      setTimeout(() => {
        navigate('/')
        window.location.reload() // لتحديث معلومات المستخدم في Layout
      }, 2000)
    } else {
      // إذا لم يكن هناك توكن، إعادة توجيه للرئيسية
      navigate('/')
    }
  }, [searchParams, navigate])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <CheckCircle className="h-16 w-16 text-green-500" />
          </div>
          <CardTitle className="text-2xl">تم تسجيل الدخول بنجاح!</CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-gray-600 dark:text-gray-300 mb-4">
            مرحباً بك في منصة استضافة البوتات
          </p>
          <div className="flex items-center justify-center space-x-2 rtl:space-x-reverse">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span className="text-sm text-gray-500">جاري إعادة التوجيه...</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default AuthSuccess

