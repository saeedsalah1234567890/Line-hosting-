import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Server, 
  Play, 
  Square, 
  RotateCcw,
  FileText,
  Upload,
  Download,
  Trash2,
  Plus,
  Code,
  Terminal,
  Settings,
  AlertCircle,
  CheckCircle,
  Loader2,
  Eye,
  Edit
} from 'lucide-react'

const Hosting = () => {
  const [user, setUser] = useState(null)
  const [bots, setBots] = useState([])
  const [languages, setLanguages] = useState([])
  const [loading, setLoading] = useState(true)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [selectedBot, setSelectedBot] = useState(null)
  const [botLogs, setBotLogs] = useState('')
  const [botFiles, setBotFiles] = useState([])
  const [selectedFile, setSelectedFile] = useState(null)
  const [fileContent, setFileContent] = useState('')
  const [showLogsModal, setShowLogsModal] = useState(false)
  const [showFilesModal, setShowFilesModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)

  // Form states
  const [newBotName, setNewBotName] = useState('')
  const [selectedLanguage, setSelectedLanguage] = useState('')
  const [creating, setCreating] = useState(false)

  useEffect(() => {
    fetchUserInfo()
    fetchLanguages()
    fetchUserBots()
  }, [])

  const fetchUserInfo = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
      }
    } catch (error) {
      console.error('Error fetching user info:', error)
    }
  }

  const fetchLanguages = async () => {
    try {
      const response = await fetch('/api/hosting/languages')
      if (response.ok) {
        const data = await response.json()
        setLanguages(data.languages || [])
      }
    } catch (error) {
      console.error('Error fetching languages:', error)
    }
  }

  const fetchUserBots = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/hosting/my-bots', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setBots(data.bots || [])
      } else if (response.status === 403) {
        setBots([])
      }
    } catch (error) {
      console.error('Error fetching user bots:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateBot = async (e) => {
    e.preventDefault()
    
    if (!newBotName.trim() || !selectedLanguage) {
      alert('يرجى ملء جميع الحقول')
      return
    }

    setCreating(true)

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/hosting/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          bot_name: newBotName.trim(),
          language: selectedLanguage
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        setNewBotName('')
        setSelectedLanguage('')
        setShowCreateForm(false)
        await fetchUserBots()
      } else {
        alert(data.error || 'حدث خطأ أثناء إنشاء البوت')
      }
    } catch (error) {
      console.error('Error creating bot:', error)
      alert('حدث خطأ أثناء إنشاء البوت')
    } finally {
      setCreating(false)
    }
  }

  const handleBotAction = async (botId, action) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/hosting/${botId}/${action}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        await fetchUserBots()
      } else {
        alert(data.error || `حدث خطأ أثناء ${action}`)
      }
    } catch (error) {
      console.error(`Error ${action} bot:`, error)
      alert(`حدث خطأ أثناء ${action}`)
    }
  }

  const handleDeleteBot = async (botId, botName) => {
    if (!confirm(`هل أنت متأكد من حذف البوت "${botName}"؟ هذا الإجراء لا يمكن التراجع عنه.`)) {
      return
    }

    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/hosting/${botId}/delete`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        await fetchUserBots()
      } else {
        alert(data.error || 'حدث خطأ أثناء حذف البوت')
      }
    } catch (error) {
      console.error('Error deleting bot:', error)
      alert('حدث خطأ أثناء حذف البوت')
    }
  }

  const fetchBotLogs = async (botId) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/hosting/${botId}/logs`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setBotLogs(data.logs || 'لا توجد سجلات متاحة')
      } else {
        setBotLogs('حدث خطأ أثناء جلب السجلات')
      }
    } catch (error) {
      console.error('Error fetching bot logs:', error)
      setBotLogs('حدث خطأ أثناء جلب السجلات')
    }
  }

  const fetchBotFiles = async (botId) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/hosting/${botId}/files`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setBotFiles(data.files || [])
      } else {
        setBotFiles([])
        alert('حدث خطأ أثناء جلب الملفات')
      }
    } catch (error) {
      console.error('Error fetching bot files:', error)
      setBotFiles([])
    }
  }

  const handleFileEdit = (file) => {
    setSelectedFile(file)
    setFileContent(file.content)
    setShowEditModal(true)
  }

  const handleFileSave = async () => {
    if (!selectedFile || !selectedBot) return

    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/hosting/${selectedBot.id}/files/${selectedFile.path}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          content: fileContent
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        setShowEditModal(false)
        await fetchBotFiles(selectedBot.id)
      } else {
        alert(data.error || 'حدث خطأ أثناء حفظ الملف')
      }
    } catch (error) {
      console.error('Error saving file:', error)
      alert('حدث خطأ أثناء حفظ الملف')
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'running': return 'bg-green-600'
      case 'stopped': return 'bg-gray-600'
      case 'error': return 'bg-red-600'
      default: return 'bg-gray-600'
    }
  }

  const getStatusText = (status) => {
    switch (status) {
      case 'running': return 'يعمل'
      case 'stopped': return 'متوقف'
      case 'error': return 'خطأ'
      default: return 'غير معروف'
    }
  }

  const getLanguageIcon = (language) => {
    const icons = {
      'nodejs': '🟢',
      'python': '🐍',
      'java': '☕',
      'php': '🐘',
      'bash': '💻'
    }
    return icons[language] || '📄'
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="mr-2 text-gray-600">جاري التحميل...</span>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <Server className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">تسجيل الدخول مطلوب</h2>
        <p className="text-gray-600 mb-6">يرجى تسجيل الدخول لإدارة استضافة البوتات</p>
        <Button asChild>
          <a href="/api/auth/login">تسجيل الدخول بـ Discord</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">استضافة البوتات</h1>
          <p className="text-gray-600">إدارة وتشغيل بوتات Discord الخاصة بك</p>
        </div>
        <Button onClick={() => setShowCreateForm(true)} className="flex items-center space-x-2 rtl:space-x-reverse">
          <Plus className="h-4 w-4" />
          <span>إنشاء بوت جديد</span>
        </Button>
      </div>

      {/* Create Bot Form */}
      {showCreateForm && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle>إنشاء بوت جديد</CardTitle>
            <CardDescription>اختر اسم البوت ولغة البرمجة</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateBot} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  اسم البوت
                </label>
                <input
                  type="text"
                  value={newBotName}
                  onChange={(e) => setNewBotName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="مثال: MyAwesomeBot"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  لغة البرمجة
                </label>
                <select
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">اختر لغة البرمجة</option>
                  {languages.map((lang) => (
                    <option key={lang.id} value={lang.id}>
                      {getLanguageIcon(lang.id)} {lang.name}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="flex space-x-2 rtl:space-x-reverse">
                <Button type="submit" disabled={creating}>
                  {creating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin ml-2" />
                      جاري الإنشاء...
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4 ml-2" />
                      إنشاء البوت
                    </>
                  )}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowCreateForm(false)}>
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Bots List */}
      {bots.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <Server className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">لا توجد بوتات</h3>
            <p className="text-gray-600 mb-6">
              {user.has_active_subscription === false 
                ? 'تحتاج إلى اشتراك نشط لإنشاء بوتات'
                : 'ابدأ بإنشاء أول بوت لك'
              }
            </p>
            {user.has_active_subscription === false ? (
              <Button asChild>
                <a href="/subscriptions">عرض خطط الاشتراك</a>
              </Button>
            ) : (
              <Button onClick={() => setShowCreateForm(true)}>
                <Plus className="h-4 w-4 ml-2" />
                إنشاء بوت جديد
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bots.map((bot) => (
            <Card key={bot.id} className="relative">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <span className="text-2xl">{getLanguageIcon(bot.language)}</span>
                    <div>
                      <CardTitle className="text-lg">{bot.bot_name}</CardTitle>
                      <CardDescription>{languages.find(l => l.id === bot.language)?.name}</CardDescription>
                    </div>
                  </div>
                  <Badge className={getStatusColor(bot.status)}>
                    {getStatusText(bot.status)}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-3">
                  {/* Bot Info */}
                  <div className="text-sm text-gray-600">
                    <div>تم الإنشاء: {new Date(bot.created_at).toLocaleDateString('ar-SA')}</div>
                    {bot.last_started && (
                      <div>آخر تشغيل: {new Date(bot.last_started).toLocaleDateString('ar-SA')}</div>
                    )}
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    {bot.status === 'running' ? (
                      <>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleBotAction(bot.id, 'stop')}
                        >
                          <Square className="h-3 w-3 ml-1" />
                          إيقاف
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleBotAction(bot.id, 'restart')}
                        >
                          <RotateCcw className="h-3 w-3 ml-1" />
                          إعادة تشغيل
                        </Button>
                      </>
                    ) : (
                      <>
                        <Button 
                          size="sm"
                          onClick={() => handleBotAction(bot.id, 'start')}
                        >
                          <Play className="h-3 w-3 ml-1" />
                          تشغيل
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => {
                            setSelectedBot(bot)
                            fetchBotFiles(bot.id)
                            setShowFilesModal(true)
                          }}
                        >
                          <Code className="h-3 w-3 ml-1" />
                          الملفات
                        </Button>
                      </>
                    )}
                    
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => {
                        setSelectedBot(bot)
                        fetchBotLogs(bot.id)
                        setShowLogsModal(true)
                      }}
                    >
                      <Terminal className="h-3 w-3 ml-1" />
                      السجلات
                    </Button>
                    
                    <Button 
                      size="sm" 
                      variant="destructive"
                      onClick={() => handleDeleteBot(bot.id, bot.bot_name)}
                    >
                      <Trash2 className="h-3 w-3 ml-1" />
                      حذف
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Logs Modal */}
      {showLogsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-4xl max-h-96 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">سجلات البوت: {selectedBot?.bot_name}</h3>
              <Button variant="outline" onClick={() => setShowLogsModal(false)}>
                إغلاق
              </Button>
            </div>
            <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-auto max-h-80">
              <pre>{botLogs}</pre>
            </div>
          </div>
        </div>
      )}

      {/* Files Modal */}
      {showFilesModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-6xl max-h-96 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">ملفات البوت: {selectedBot?.bot_name}</h3>
              <Button variant="outline" onClick={() => setShowFilesModal(false)}>
                إغلاق
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-h-80 overflow-auto">
              {botFiles.map((file, index) => (
                <Card key={index} className="cursor-pointer hover:bg-gray-50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">{file.name}</div>
                        <div className="text-sm text-gray-600">{(file.size / 1024).toFixed(1)} KB</div>
                      </div>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleFileEdit(file)}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Edit File Modal */}
      {showEditModal && selectedFile && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-6xl max-h-96 overflow-hidden">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">تحرير الملف: {selectedFile.name}</h3>
              <div className="space-x-2 rtl:space-x-reverse">
                <Button onClick={handleFileSave}>
                  حفظ
                </Button>
                <Button variant="outline" onClick={() => setShowEditModal(false)}>
                  إلغاء
                </Button>
              </div>
            </div>
            <textarea
              value={fileContent}
              onChange={(e) => setFileContent(e.target.value)}
              className="w-full h-80 p-4 border border-gray-300 rounded-lg font-mono text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="محتوى الملف..."
            />
          </div>
        </div>
      )}
    </div>
  )
}

export default Hosting

