import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  User,
  Coins,
  CreditCard,
  Server,
  Activity,
  TrendingUp,
  Calendar,
  Clock,
  Play,
  Square,
  AlertTriangle,
  CheckCircle,
  Loader2,
  BarChart3,
  PieChart,
  ArrowRight
} from 'lucide-react'

const Dashboard = () => {
  const [user, setUser] = useState(null)
  const [stats, setStats] = useState({
    points: 0,
    subscription: null,
    bots: [],
    recentActivity: []
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) {
        setLoading(false)
        return
      }

      // جلب معلومات المستخدم
      const userResponse = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      
      if (userResponse.ok) {
        const userData = await userResponse.json()
        setUser(userData)
      }

      // جلب رصيد النقاط
      const pointsResponse = await fetch('/api/points/balance', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      
      let pointsData = { balance: 0 }
      if (pointsResponse.ok) {
        pointsData = await pointsResponse.json()
      }

      // جلب حالة الاشتراك
      const subscriptionResponse = await fetch('/api/subscription/status', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      
      let subscriptionData = { hasActiveSubscription: false }
      if (subscriptionResponse.ok) {
        subscriptionData = await subscriptionResponse.json()
      }

      // جلب البوتات
      const botsResponse = await fetch('/api/hosting/my-bots', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      
      let botsData = { bots: [] }
      if (botsResponse.ok) {
        botsData = await botsResponse.json()
      }

      // جلب النشاط الأخير
      const activityResponse = await fetch('/api/points/history?limit=5', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      
      let activityData = []
      if (activityResponse.ok) {
        activityData = await activityResponse.json()
      }

      setStats({
        points: pointsData.balance,
        subscription: subscriptionData.hasActiveSubscription ? subscriptionData.subscription : null,
        bots: botsData.bots || [],
        recentActivity: activityData.slice(0, 5) || []
      })

    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'running': return 'text-green-600 bg-green-100'
      case 'stopped': return 'text-gray-600 bg-gray-100'
      case 'error': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const getStatusText = (status) => {
    switch (status) {
      case 'running': return 'يعمل'
      case 'stopped': return 'متوقف'
      case 'error': return 'خطأ'
      default: return 'غير معروف'
    }
  }

  const getActivityIcon = (type) => {
    switch (type) {
      case 'earned': return <TrendingUp className="h-4 w-4 text-green-600" />
      case 'spent': return <CreditCard className="h-4 w-4 text-blue-600" />
      case 'bonus': return <Coins className="h-4 w-4 text-yellow-600" />
      default: return <Activity className="h-4 w-4 text-gray-600" />
    }
  }

  const getActivityColor = (type) => {
    switch (type) {
      case 'earned': return 'text-green-600'
      case 'spent': return 'text-blue-600'
      case 'bonus': return 'text-yellow-600'
      default: return 'text-gray-600'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="mr-2 text-gray-600">جاري التحميل...</span>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <User className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">تسجيل الدخول مطلوب</h2>
        <p className="text-gray-600 mb-6">يرجى تسجيل الدخول لعرض لوحة التحكم</p>
        <Button asChild>
          <a href="/api/auth/login">تسجيل الدخول بـ Discord</a>
        </Button>
      </div>
    )
  }

  const runningBots = stats.bots.filter(bot => bot.status === 'running').length
  const totalBots = stats.bots.length

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <div className="flex items-center space-x-4 rtl:space-x-reverse">
          <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
            {user.avatar ? (
              <img 
                src={`https://cdn.discordapp.com/avatars/${user.discord_id}/${user.avatar}.png`}
                alt={user.username}
                className="w-12 h-12 rounded-full"
              />
            ) : (
              <User className="h-8 w-8" />
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold">مرحباً، {user.username}!</h1>
            <p className="text-blue-100">إليك نظرة سريعة على حسابك</p>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Points Balance */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">رصيد النقاط</CardTitle>
            <Coins className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.points}</div>
            <p className="text-xs text-muted-foreground">
              <Button variant="link" className="p-0 h-auto text-xs" asChild>
                <a href="/points">كسب المزيد <ArrowRight className="h-3 w-3 mr-1" /></a>
              </Button>
            </p>
          </CardContent>
        </Card>

        {/* Subscription Status */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الاشتراك</CardTitle>
            <CreditCard className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            {stats.subscription ? (
              <>
                <div className="text-2xl font-bold text-green-600">نشط</div>
                <p className="text-xs text-muted-foreground">
                  {stats.subscription.days_remaining} يوم متبقي
                </p>
              </>
            ) : (
              <>
                <div className="text-2xl font-bold text-gray-600">غير نشط</div>
                <p className="text-xs text-muted-foreground">
                  <Button variant="link" className="p-0 h-auto text-xs" asChild>
                    <a href="/subscriptions">اشترك الآن <ArrowRight className="h-3 w-3 mr-1" /></a>
                  </Button>
                </p>
              </>
            )}
          </CardContent>
        </Card>

        {/* Bots Count */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">البوتات</CardTitle>
            <Server className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{totalBots}</div>
            <p className="text-xs text-muted-foreground">
              {runningBots} يعمل من أصل {totalBots}
            </p>
          </CardContent>
        </Card>

        {/* Account Status */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">حالة الحساب</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">نشط</div>
            <p className="text-xs text-muted-foreground">
              عضو منذ {new Date(user.created_at).toLocaleDateString('ar-SA')}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Bots Overview */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
              <Server className="h-5 w-5" />
              <span>البوتات الخاصة بك</span>
            </CardTitle>
            <CardDescription>
              إدارة سريعة لبوتاتك
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats.bots.length === 0 ? (
              <div className="text-center py-8">
                <Server className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">لا توجد بوتات بعد</p>
                <Button asChild>
                  <a href="/hosting">إنشاء أول بوت</a>
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {stats.bots.slice(0, 5).map((bot) => (
                  <div key={bot.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3 rtl:space-x-reverse">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Server className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <div className="font-medium">{bot.bot_name}</div>
                        <div className="text-sm text-gray-600">{bot.language}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <Badge className={getStatusColor(bot.status)}>
                        {getStatusText(bot.status)}
                      </Badge>
                      {bot.status === 'running' ? (
                        <Square className="h-4 w-4 text-red-600" />
                      ) : (
                        <Play className="h-4 w-4 text-green-600" />
                      )}
                    </div>
                  </div>
                ))}
                {stats.bots.length > 5 && (
                  <div className="text-center pt-2">
                    <Button variant="outline" asChild>
                      <a href="/hosting">عرض جميع البوتات ({stats.bots.length})</a>
                    </Button>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
              <Activity className="h-5 w-5" />
              <span>النشاط الأخير</span>
            </CardTitle>
            <CardDescription>
              آخر العمليات على حسابك
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats.recentActivity.length === 0 ? (
              <div className="text-center py-8">
                <Activity className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">لا يوجد نشاط بعد</p>
              </div>
            ) : (
              <div className="space-y-3">
                {stats.recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-3 rtl:space-x-reverse">
                    <div className="flex-shrink-0">
                      {getActivityIcon(activity.transaction_type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {activity.reason}
                      </p>
                      <p className="text-xs text-gray-600">
                        {new Date(activity.created_at).toLocaleDateString('ar-SA')}
                      </p>
                    </div>
                    <div className={`text-sm font-medium ${getActivityColor(activity.transaction_type)}`}>
                      {activity.transaction_type === 'earned' ? '+' : '-'}{activity.amount}
                    </div>
                  </div>
                ))}
                <div className="text-center pt-2">
                  <Button variant="outline" size="sm" asChild>
                    <a href="/points">عرض جميع العمليات</a>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Subscription Alert */}
      {stats.subscription && stats.subscription.is_expiring_soon && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
              <div className="flex-1">
                <h3 className="font-medium text-yellow-800">اشتراكك ينتهي قريباً!</h3>
                <p className="text-sm text-yellow-700">
                  يتبقى {stats.subscription.days_remaining} أيام فقط. قم بالتجديد لتجنب انقطاع الخدمة.
                </p>
              </div>
              <Button asChild>
                <a href="/subscriptions">تجديد الاشتراك</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>إجراءات سريعة</CardTitle>
          <CardDescription>الأعمال الشائعة التي قد تحتاجها</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col" asChild>
              <a href="/points">
                <Coins className="h-6 w-6 mb-2" />
                <span>كسب نقاط</span>
              </a>
            </Button>
            
            <Button variant="outline" className="h-20 flex-col" asChild>
              <a href="/subscriptions">
                <CreditCard className="h-6 w-6 mb-2" />
                <span>إدارة الاشتراك</span>
              </a>
            </Button>
            
            <Button variant="outline" className="h-20 flex-col" asChild>
              <a href="/hosting">
                <Server className="h-6 w-6 mb-2" />
                <span>إدارة البوتات</span>
              </a>
            </Button>
            
            <Button variant="outline" className="h-20 flex-col">
              <BarChart3 className="h-6 w-6 mb-2" />
              <span>الإحصائيات</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard

