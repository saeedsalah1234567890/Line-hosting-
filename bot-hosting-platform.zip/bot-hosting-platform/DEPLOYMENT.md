# دليل نشر منصة استضافة البوتات

## 🚀 نشر المشروع على منصات الاستضافة المختلفة

### المتغيرات المطلوبة

قبل نشر المشروع، تأكد من تعيين هذه المتغيرات في منصة الاستضافة:

#### متغيرات مطلوبة:
```
DISCORD_CLIENT_ID=your-discord-client-id
DISCORD_CLIENT_SECRET=your-discord-client-secret
```

#### متغيرات اختيارية (لها قيم افتراضية):
```
SECRET_KEY=your-super-secret-key
JWT_SECRET_KEY=your-jwt-secret-key
ADMIN_DISCORD_IDS=1204079462166175754,1131346177196052561
FLASK_ENV=production
DATABASE_URL=sqlite:///database/app.db
DISCORD_REDIRECT_URI=https://yourdomain.com/api/auth/callback
```

---

## 📱 Vercel

### 1. إعداد المتغيرات:
```bash
# في لوحة تحكم Vercel أو عبر CLI
vercel env add DISCORD_CLIENT_ID
vercel env add DISCORD_CLIENT_SECRET
vercel env add SECRET_KEY
vercel env add JWT_SECRET_KEY
vercel env add ADMIN_DISCORD_IDS
```

### 2. إنشاء ملف `vercel.json`:
```json
{
  "version": 2,
  "builds": [
    {
      "src": "backend/src/main.py",
      "use": "@vercel/python"
    },
    {
      "src": "frontend/package.json",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "backend/src/main.py"
    },
    {
      "src": "/(.*)",
      "dest": "frontend/dist/$1"
    }
  ]
}
```

### 3. النشر:
```bash
vercel --prod
```

---

## 🚂 Railway

### 1. إعداد المتغيرات:
في لوحة تحكم Railway:
- اذهب إلى Variables
- أضف المتغيرات المطلوبة

### 2. النشر:
```bash
# ربط المشروع
railway login
railway link

# نشر
railway up
```

---

## 🌊 Heroku

### 1. إعداد المتغيرات:
```bash
# عبر CLI
heroku config:set DISCORD_CLIENT_ID=your-client-id
heroku config:set DISCORD_CLIENT_SECRET=your-client-secret
heroku config:set SECRET_KEY=your-secret-key
heroku config:set JWT_SECRET_KEY=your-jwt-secret
heroku config:set ADMIN_DISCORD_IDS=1204079462166175754,1131346177196052561
```

### 2. إنشاء ملف `Procfile`:
```
web: cd backend && python src/main.py
```

### 3. النشر:
```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

---

## 🐳 Docker

### 1. إنشاء ملف `docker-compose.yml`:
```yaml
version: '3.8'
services:
  bot-hosting:
    build: .
    ports:
      - "5000:5000"
    environment:
      - DISCORD_CLIENT_ID=${DISCORD_CLIENT_ID}
      - DISCORD_CLIENT_SECRET=${DISCORD_CLIENT_SECRET}
      - SECRET_KEY=${SECRET_KEY}
      - JWT_SECRET_KEY=${JWT_SECRET_KEY}
      - ADMIN_DISCORD_IDS=${ADMIN_DISCORD_IDS}
      - FLASK_ENV=production
    volumes:
      - ./database:/app/database
      - /var/run/docker.sock:/var/run/docker.sock
```

### 2. النشر:
```bash
docker-compose up -d
```

---

## 📱 Termux (Android)

### 1. تثبيت المتطلبات:
```bash
pkg update && pkg upgrade
pkg install python git docker
pip install -r requirements.txt
```

### 2. إعداد المتغيرات:
```bash
# إنشاء ملف .env للتطوير المحلي
cp backend/.env.example backend/.env
nano backend/.env
```

### 3. تشغيل المشروع:
```bash
cd backend
python src/main.py
```

---

## 🔧 إعداد Discord OAuth

### 1. إنشاء تطبيق Discord:
1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
2. انقر على "New Application"
3. اختر اسم للتطبيق

### 2. إعداد OAuth2:
1. اذهب إلى OAuth2 → General
2. أضف Redirect URI:
   - للتطوير: `http://localhost:5000/api/auth/callback`
   - للإنتاج: `https://yourdomain.com/api/auth/callback`

### 3. الحصول على المعرفات:
- انسخ `Client ID` و `Client Secret`
- أضفهما كمتغيرات بيئة

---

## 🛡️ الأمان

### نصائح مهمة:
1. **لا ترفع ملف `.env`** أبداً إلى Git
2. **استخدم مفاتيح قوية** للإنتاج
3. **قم بتحديث المفاتيح** بانتظام
4. **استخدم HTTPS** في الإنتاج
5. **فعل CORS** للنطاقات المحددة فقط

### مثال على مفاتيح قوية:
```bash
# يمكنك إنشاء مفاتيح عشوائية باستخدام:
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

---

## 🔍 استكشاف الأخطاء

### مشاكل شائعة:

#### 1. خطأ Discord OAuth:
```
Error: Invalid redirect URI
```
**الحل:** تأكد من أن `DISCORD_REDIRECT_URI` يطابق ما هو مسجل في Discord

#### 2. خطأ قاعدة البيانات:
```
Error: database is locked
```
**الحل:** تأكد من أن مجلد `database` قابل للكتابة

#### 3. خطأ المتغيرات:
```
Error: DISCORD_CLIENT_ID not found
```
**الحل:** تأكد من تعيين جميع المتغيرات المطلوبة

---

## 📞 الدعم

إذا واجهت أي مشاكل في النشر:
1. تحقق من السجلات (logs)
2. تأكد من تعيين جميع المتغيرات
3. تحقق من إعدادات Discord OAuth
4. تأكد من أن المنافذ مفتوحة

---

## 🎯 ملاحظات للمشرفين

### Discord IDs المشرفين الحاليين:
- `1204079462166175754` - المشرف الرئيسي
- `1131346177196052561` - المشرف المساعد

### إضافة مشرف جديد:
1. أضف Discord ID إلى `ADMIN_DISCORD_IDS`
2. أعد تشغيل التطبيق
3. المستخدم سيحصل على صلاحيات المشرف عند تسجيل الدخول التالي

### إدارة المشرفين يدوياً:
```bash
# إضافة مشرف
python backend/create_admin.py create DISCORD_ID USERNAME

# عرض المشرفين
python backend/create_admin.py list

# إزالة مشرف
python backend/create_admin.py remove DISCORD_ID
```

