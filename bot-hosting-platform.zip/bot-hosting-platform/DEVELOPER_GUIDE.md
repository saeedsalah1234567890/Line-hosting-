# دليل المطور - منصة استضافة البوتات

## 🛠️ نظرة عامة تقنية

هذا الدليل مخصص للمطورين الذين يريدون فهم البنية التقنية للمنصة أو المساهمة في تطويرها.

---

## 📋 جدول المحتويات

1. [البنية التقنية](#البنية-التقنية)
2. [إعداد بيئة التطوير](#إعداد-بيئة-التطوير)
3. [الواجهة الخلفية (Backend)](#الواجهة-الخلفية-backend)
4. [الواجهة الأمامية (Frontend)](#الواجهة-الأمامية-frontend)
5. [قاعدة البيانات](#قاعدة-البيانات)
6. [نظام Docker](#نظام-docker)
7. [API Documentation](#api-documentation)
8. [الأمان](#الأمان)
9. [النشر](#النشر)
10. [المساهمة](#المساهمة)

---

## 🏗️ البنية التقنية

### نظرة عامة على المعمارية

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │    Backend      │    │   Database      │
│   (React)       │◄──►│   (Flask)       │◄──►│   (SQLite)      │
│   Port: 3000    │    │   Port: 5000    │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Static Files  │    │   Docker API    │    │   File System   │
│   (Build)       │    │   (Containers)  │    │   (Bot Files)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### التقنيات المستخدمة

#### الواجهة الأمامية
- **React 18**: مكتبة UI الرئيسية
- **React Router**: التوجيه
- **Tailwind CSS**: التصميم والأنماط
- **Lucide React**: الأيقونات
- **Vite**: أداة البناء والتطوير

#### الواجهة الخلفية
- **Flask**: إطار العمل الرئيسي
- **SQLAlchemy**: ORM لقاعدة البيانات
- **Flask-JWT-Extended**: إدارة JWT
- **Flask-CORS**: دعم CORS
- **Requests**: HTTP client
- **Docker SDK**: إدارة الحاويات

#### قاعدة البيانات
- **SQLite**: قاعدة البيانات الرئيسية
- **Alembic**: إدارة migrations (اختياري)

#### البنية التحتية
- **Docker**: تشغيل البوتات في حاويات معزولة
- **Nginx**: Reverse proxy (للإنتاج)
- **Systemd**: إدارة الخدمات (للإنتاج)

---

## ⚙️ إعداد بيئة التطوير

### المتطلبات الأساسية

```bash
# Node.js (18.x أو أحدث)
node --version

# Python (3.9 أو أحدث)
python3 --version

# Docker (20.x أو أحدث)
docker --version

# Git
git --version
```

### إعداد المشروع

#### 1. استنساخ المشروع
```bash
git clone <repository-url>
cd bot-hosting-platform
```

#### 2. إعداد الواجهة الخلفية
```bash
cd backend

# إنشاء بيئة افتراضية
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# أو
venv\Scripts\activate     # Windows

# تثبيت المتطلبات
pip install -r requirements.txt

# إعداد متغيرات البيئة
cp .env.example .env
# عدل .env وأضف القيم المطلوبة
```

#### 3. إعداد الواجهة الأمامية
```bash
cd frontend

# تثبيت المتطلبات
npm install

# أو باستخدام yarn
yarn install
```

#### 4. إعداد قاعدة البيانات
```bash
cd backend
source venv/bin/activate

# إنشاء قاعدة البيانات
python -c "from src.main import app, db; app.app_context().push(); db.create_all()"
```

### تشغيل بيئة التطوير

#### تشغيل الواجهة الخلفية
```bash
cd backend
source venv/bin/activate
python src/main.py
```

#### تشغيل الواجهة الأمامية
```bash
cd frontend
npm run dev
```

الآن يمكنك الوصول إلى:
- **الواجهة الأمامية**: http://localhost:3000
- **الواجهة الخلفية**: http://localhost:5000
- **API Docs**: http://localhost:5000/api/docs (إذا كان متاحاً)

---

## 🔧 الواجهة الخلفية (Backend)

### هيكل المجلدات

```
backend/
├── src/
│   ├── main.py              # نقطة الدخول الرئيسية
│   ├── config.py            # إعدادات التطبيق
│   ├── models/
│   │   └── user.py          # نماذج قاعدة البيانات
│   └── routes/
│       ├── auth.py          # مسارات المصادقة
│       ├── points.py        # مسارات النقاط
│       ├── subscription.py  # مسارات الاشتراكات
│       ├── hosting.py       # مسارات الاستضافة
│       └── admin.py         # مسارات المشرف
├── requirements.txt         # متطلبات Python
├── create_admin.py         # أداة إدارة المشرفين
└── database/               # ملفات قاعدة البيانات
```

### نماذج قاعدة البيانات

#### User Model
```python
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    discord_id = db.Column(db.String(20), unique=True, nullable=False)
    username = db.Column(db.String(100), nullable=False)
    avatar = db.Column(db.String(100))
    points = db.Column(db.Integer, default=0)
    is_admin = db.Column(db.Boolean, default=False)
    is_banned = db.Column(db.Boolean, default=False)
    last_ad_watch = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
```

#### Subscription Model
```python
class Subscription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    plan_type = db.Column(db.String(20), nullable=False)  # 'weekly', 'monthly'
    points_cost = db.Column(db.Integer, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    auto_renew = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
```

#### Hosting Model
```python
class Hosting(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    bot_name = db.Column(db.String(100), nullable=False)
    language = db.Column(db.String(20), nullable=False)
    status = db.Column(db.String(20), default='stopped')
    container_id = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_started = db.Column(db.DateTime)
    last_stopped = db.Column(db.DateTime)
```

### مسارات API الرئيسية

#### المصادقة (`/api/auth`)
- `GET /login` - بدء OAuth مع Discord
- `GET /callback` - معالجة callback من Discord
- `GET /me` - معلومات المستخدم الحالي
- `POST /logout` - تسجيل الخروج

#### النقاط (`/api/points`)
- `GET /balance` - رصيد النقاط
- `GET /ad-status` - حالة الإعلانات
- `POST /watch-ad` - مشاهدة إعلان
- `GET /history` - تاريخ النقاط
- `GET /stats` - إحصائيات المستخدم
- `GET /leaderboard` - قائمة المتصدرين

#### الاشتراكات (`/api/subscription`)
- `GET /plans` - خطط الاشتراك المتاحة
- `POST /purchase` - شراء اشتراك
- `GET /status` - حالة الاشتراك
- `POST /toggle-auto-renew` - تفعيل/إلغاء التجديد التلقائي
- `POST /cancel` - إلغاء الاشتراك

#### الاستضافة (`/api/hosting`)
- `GET /my-bots` - بوتات المستخدم
- `POST /create-bot` - إنشاء بوت جديد
- `POST /<bot_id>/start` - تشغيل بوت
- `POST /<bot_id>/stop` - إيقاف بوت
- `DELETE /<bot_id>` - حذف بوت
- `GET /<bot_id>/files` - ملفات البوت
- `GET /<bot_id>/logs` - سجلات البوت

### نظام المصادقة

#### Discord OAuth Flow
```python
@auth_bp.route('/login')
def login():
    discord_oauth_url = f"https://discord.com/api/oauth2/authorize?" \
                       f"client_id={Config.DISCORD_CLIENT_ID}&" \
                       f"redirect_uri={Config.DISCORD_REDIRECT_URI}&" \
                       f"response_type=code&scope=identify"
    return redirect(discord_oauth_url)

@auth_bp.route('/callback')
def callback():
    code = request.args.get('code')
    # تبادل الكود للحصول على access token
    # جلب معلومات المستخدم من Discord
    # إنشاء/تحديث المستخدم في قاعدة البيانات
    # إنشاء JWT token
    # إعادة توجيه للواجهة الأمامية
```

#### JWT Token Management
```python
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity

# إنشاء token
access_token = create_access_token(
    identity=user.id,
    additional_claims={'is_admin': user.is_admin}
)

# حماية المسارات
@jwt_required()
def protected_route():
    current_user_id = get_jwt_identity()
    # منطق المسار
```

### نظام إدارة الحاويات

#### إنشاء حاوية بوت
```python
import docker

def create_bot_container(user_id, bot_name, language):
    client = docker.from_env()
    
    # إعداد الحاوية حسب اللغة
    if language == 'nodejs':
        image = 'node:18-alpine'
        command = ['npm', 'start']
    elif language == 'python':
        image = 'python:3.9-alpine'
        command = ['python', 'main.py']
    
    # إنشاء الحاوية
    container = client.containers.create(
        image=image,
        command=command,
        name=f'bothost_{user_id}_{bot_name}',
        working_dir='/app',
        volumes={
            f'/path/to/user/{user_id}/{bot_name}': {
                'bind': '/app',
                'mode': 'rw'
            }
        },
        mem_limit='512m',
        cpu_quota=50000,  # 50% CPU
        network_mode='bridge'
    )
    
    return container.id
```

---

## 🎨 الواجهة الأمامية (Frontend)

### هيكل المجلدات

```
frontend/
├── public/
│   ├── index.html
│   └── favicon.ico
├── src/
│   ├── components/
│   │   ├── ui/              # مكونات UI أساسية
│   │   └── Layout.jsx       # تخطيط الصفحة
│   ├── pages/
│   │   ├── Home.jsx         # الصفحة الرئيسية
│   │   ├── Dashboard.jsx    # لوحة التحكم
│   │   ├── Points.jsx       # صفحة النقاط
│   │   ├── Subscriptions.jsx # صفحة الاشتراكات
│   │   ├── Hosting.jsx      # صفحة الاستضافة
│   │   └── Admin.jsx        # لوحة المشرف
│   ├── lib/
│   │   └── utils.js         # دوال مساعدة
│   ├── App.jsx              # المكون الرئيسي
│   ├── App.css              # الأنماط الرئيسية
│   └── main.jsx             # نقطة الدخول
├── package.json
└── vite.config.js
```

### مكونات UI الأساسية

#### Button Component
```jsx
const Button = ({ children, variant = 'default', size = 'default', ...props }) => {
  const baseClasses = 'inline-flex items-center justify-center rounded-md font-medium transition-colors'
  const variants = {
    default: 'bg-blue-600 text-white hover:bg-blue-700',
    outline: 'border border-gray-300 bg-white hover:bg-gray-50',
    destructive: 'bg-red-600 text-white hover:bg-red-700'
  }
  const sizes = {
    default: 'h-10 px-4 py-2',
    sm: 'h-8 px-3 text-sm',
    lg: 'h-12 px-8'
  }
  
  return (
    <button 
      className={`${baseClasses} ${variants[variant]} ${sizes[size]}`}
      {...props}
    >
      {children}
    </button>
  )
}
```

#### Card Component
```jsx
const Card = ({ children, className = '', ...props }) => (
  <div className={`rounded-lg border bg-white shadow-sm ${className}`} {...props}>
    {children}
  </div>
)

const CardHeader = ({ children, className = '', ...props }) => (
  <div className={`flex flex-col space-y-1.5 p-6 ${className}`} {...props}>
    {children}
  </div>
)

const CardContent = ({ children, className = '', ...props }) => (
  <div className={`p-6 pt-0 ${className}`} {...props}>
    {children}
  </div>
)
```

### إدارة الحالة

#### Context للمستخدم
```jsx
const UserContext = createContext()

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (token) {
      fetchUser(token)
    } else {
      setLoading(false)
    }
  }, [])

  const fetchUser = async (token) => {
    try {
      const response = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
      }
    } catch (error) {
      console.error('Error fetching user:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <UserContext.Provider value={{ user, setUser, loading }}>
      {children}
    </UserContext.Provider>
  )
}
```

### التوجيه والحماية

#### Protected Routes
```jsx
const ProtectedRoute = ({ children }) => {
  const { user, loading } = useContext(UserContext)
  
  if (loading) {
    return <div>جاري التحميل...</div>
  }
  
  if (!user) {
    return <Navigate to="/login" />
  }
  
  return children
}

// الاستخدام
<Route path="/dashboard" element={
  <ProtectedRoute>
    <Dashboard />
  </ProtectedRoute>
} />
```

#### Admin Routes
```jsx
const AdminRoute = ({ children }) => {
  const { user, loading } = useContext(UserContext)
  
  if (loading) return <div>جاري التحميل...</div>
  if (!user) return <Navigate to="/login" />
  if (!user.is_admin) return <Navigate to="/" />
  
  return children
}
```

---

## 🗄️ قاعدة البيانات

### تصميم قاعدة البيانات

```sql
-- جدول المستخدمين
CREATE TABLE user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discord_id VARCHAR(20) UNIQUE NOT NULL,
    username VARCHAR(100) NOT NULL,
    avatar VARCHAR(100),
    points INTEGER DEFAULT 0,
    is_admin BOOLEAN DEFAULT 0,
    is_banned BOOLEAN DEFAULT 0,
    last_ad_watch DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- جدول معاملات النقاط
CREATE TABLE point_transaction (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    transaction_type VARCHAR(20) NOT NULL, -- 'earned', 'spent'
    amount INTEGER NOT NULL,
    reason TEXT,
    balance_after INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user (id)
);

-- جدول الاشتراكات
CREATE TABLE subscription (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    plan_type VARCHAR(20) NOT NULL, -- 'weekly', 'monthly'
    points_cost INTEGER NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    auto_renew BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user (id)
);

-- جدول الاستضافة
CREATE TABLE hosting (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    bot_name VARCHAR(100) NOT NULL,
    language VARCHAR(20) NOT NULL,
    status VARCHAR(20) DEFAULT 'stopped',
    container_id VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_started DATETIME,
    last_stopped DATETIME,
    FOREIGN KEY (user_id) REFERENCES user (id)
);

-- جدول سجل الأنشطة
CREATE TABLE activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action VARCHAR(50) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user (id)
);
```

### فهارس قاعدة البيانات

```sql
-- فهارس للأداء
CREATE INDEX idx_user_discord_id ON user(discord_id);
CREATE INDEX idx_point_transaction_user_id ON point_transaction(user_id);
CREATE INDEX idx_subscription_user_id ON subscription(user_id);
CREATE INDEX idx_subscription_expires_at ON subscription(expires_at);
CREATE INDEX idx_hosting_user_id ON hosting(user_id);
CREATE INDEX idx_hosting_status ON hosting(status);
CREATE INDEX idx_activity_log_user_id ON activity_log(user_id);
CREATE INDEX idx_activity_log_created_at ON activity_log(created_at);
```

### Migration Scripts

```python
# migrations/001_initial.py
def upgrade():
    # إنشاء الجداول الأساسية
    pass

def downgrade():
    # حذف الجداول
    pass

# migrations/002_add_indexes.py
def upgrade():
    # إضافة الفهارس
    pass
```

---

## 🐳 نظام Docker

### Dockerfile للإنتاج

```dockerfile
# Multi-stage build
FROM node:18-alpine AS frontend-build
WORKDIR /app/frontend
COPY frontend/package*.json ./
RUN npm ci --only=production
COPY frontend/ ./
RUN npm run build

FROM python:3.9-alpine AS backend
WORKDIR /app
COPY backend/requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt
COPY backend/ ./
COPY --from=frontend-build /app/frontend/dist ./static

EXPOSE 5000
CMD ["python", "src/main.py"]
```

### Docker Compose للتطوير

```yaml
version: '3.8'

services:
  backend:
    build: 
      context: .
      dockerfile: Dockerfile.dev
    ports:
      - "5000:5000"
    volumes:
      - ./backend:/app
      - /var/run/docker.sock:/var/run/docker.sock
    environment:
      - FLASK_ENV=development
      - DISCORD_CLIENT_ID=${DISCORD_CLIENT_ID}
      - DISCORD_CLIENT_SECRET=${DISCORD_CLIENT_SECRET}
    depends_on:
      - redis

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.dev
    ports:
      - "3000:3000"
    volumes:
      - ./frontend:/app
      - /app/node_modules

  redis:
    image: redis:alpine
    ports:
      - "6379:6379"

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - backend
      - frontend
```

### إعداد Nginx

```nginx
events {
    worker_connections 1024;
}

http {
    upstream backend {
        server backend:5000;
    }

    upstream frontend {
        server frontend:3000;
    }

    server {
        listen 80;
        
        location /api/ {
            proxy_pass http://backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
        
        location / {
            proxy_pass http://frontend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }
    }
}
```

---

## 📚 API Documentation

### مصادقة API

جميع المسارات المحمية تتطلب JWT token في header:

```
Authorization: Bearer <jwt_token>
```

### مسارات النقاط

#### GET /api/points/balance
**الوصف**: الحصول على رصيد النقاط الحالي

**الاستجابة**:
```json
{
  "balance": 150,
  "total_earned": 300,
  "total_spent": 150
}
```

#### POST /api/points/watch-ad
**الوصف**: مشاهدة إعلان وكسب نقاط

**الاستجابة**:
```json
{
  "success": true,
  "points_earned": 3,
  "new_balance": 153,
  "next_ad_available_at": "2024-01-01T12:01:00Z"
}
```

**أخطاء محتملة**:
```json
{
  "error": "يجب الانتظار 60 ثانية بين الإعلانات",
  "next_available_in": 45
}
```

### مسارات الاشتراكات

#### GET /api/subscription/plans
**الوصف**: الحصول على خطط الاشتراك المتاحة

**الاستجابة**:
```json
{
  "plans": [
    {
      "type": "weekly",
      "name": "اشتراك أسبوعي",
      "duration_days": 7,
      "points_cost": 15,
      "features": ["استضافة بوت واحد", "512 MB ذاكرة"]
    },
    {
      "type": "monthly", 
      "name": "اشتراك شهري",
      "duration_days": 30,
      "points_cost": 60,
      "features": ["استضافة 3 بوتات", "1 GB ذاكرة"]
    }
  ]
}
```

#### POST /api/subscription/purchase
**الوصف**: شراء اشتراك

**الطلب**:
```json
{
  "plan_type": "weekly",
  "auto_renew": true
}
```

**الاستجابة**:
```json
{
  "success": true,
  "subscription": {
    "id": 123,
    "plan_type": "weekly",
    "expires_at": "2024-01-08T12:00:00Z",
    "auto_renew": true
  },
  "points_spent": 15,
  "remaining_points": 135
}
```

### مسارات الاستضافة

#### POST /api/hosting/create-bot
**الوصف**: إنشاء بوت جديد

**الطلب**:
```json
{
  "bot_name": "my-discord-bot",
  "language": "nodejs",
  "description": "بوت Discord للموسيقى"
}
```

**الاستجابة**:
```json
{
  "success": true,
  "bot": {
    "id": 456,
    "bot_name": "my-discord-bot",
    "language": "nodejs",
    "status": "stopped",
    "created_at": "2024-01-01T12:00:00Z"
  }
}
```

#### POST /api/hosting/{bot_id}/start
**الوصف**: تشغيل بوت

**الاستجابة**:
```json
{
  "success": true,
  "message": "تم تشغيل البوت بنجاح",
  "container_id": "abc123def456",
  "status": "running"
}
```

### رموز الأخطاء

| الرمز | الوصف |
|-------|--------|
| 200 | نجح الطلب |
| 400 | خطأ في البيانات المرسلة |
| 401 | غير مصرح (token غير صحيح) |
| 403 | ممنوع (صلاحيات غير كافية) |
| 404 | المورد غير موجود |
| 429 | تم تجاوز الحد المسموح |
| 500 | خطأ في الخادم |

---

## 🔒 الأمان

### إجراءات الأمان المطبقة

#### 1. مصادقة وتفويض
- **Discord OAuth 2.0**: مصادقة آمنة
- **JWT Tokens**: إدارة الجلسات
- **Role-based Access**: صلاحيات متدرجة
- **Token Expiration**: انتهاء صلاحية التوكنات

#### 2. حماية API
- **Rate Limiting**: تحديد معدل الطلبات
- **CORS Configuration**: تحديد المصادر المسموحة
- **Input Validation**: التحقق من صحة البيانات
- **SQL Injection Prevention**: استخدام ORM

#### 3. حماية الحاويات
- **Resource Limits**: تحديد موارد الحاويات
- **Network Isolation**: عزل الشبكة
- **File System Restrictions**: تقييد الوصول للملفات
- **Container Scanning**: فحص الحاويات للثغرات

#### 4. حماية البيانات
- **Environment Variables**: متغيرات البيئة الآمنة
- **Database Encryption**: تشفير قاعدة البيانات
- **Secure Headers**: headers أمان HTTP
- **Logging**: تسجيل الأنشطة المشبوهة

### إعدادات الأمان

#### Flask Security Headers
```python
from flask import Flask
from flask_talisman import Talisman

app = Flask(__name__)

# إعداد headers الأمان
Talisman(app, {
    'force_https': True,
    'strict_transport_security': True,
    'content_security_policy': {
        'default-src': "'self'",
        'script-src': "'self' 'unsafe-inline'",
        'style-src': "'self' 'unsafe-inline'"
    }
})
```

#### Rate Limiting
```python
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

@app.route('/api/points/watch-ad', methods=['POST'])
@limiter.limit("1 per minute")
def watch_ad():
    # منطق مشاهدة الإعلان
    pass
```

#### Input Validation
```python
from marshmallow import Schema, fields, validate

class CreateBotSchema(Schema):
    bot_name = fields.Str(
        required=True,
        validate=validate.Length(min=3, max=50)
    )
    language = fields.Str(
        required=True,
        validate=validate.OneOf(['nodejs', 'python', 'java', 'php', 'bash'])
    )
    description = fields.Str(
        validate=validate.Length(max=200)
    )
```

### أفضل الممارسات الأمنية

#### للمطورين
1. **لا تحفظ أسرار في الكود**: استخدم متغيرات البيئة
2. **تحقق من جميع المدخلات**: validation شامل
3. **استخدم HTTPS**: في الإنتاج دائماً
4. **حدث التبعيات**: بانتظام للحماية من الثغرات
5. **سجل الأنشطة**: لمراقبة الأمان

#### للنشر
1. **غير كلمات المرور الافتراضية**
2. **فعل firewall**: قيد الوصول للمنافذ
3. **استخدم SSL certificates**: صحيحة ومحدثة
4. **راقب السجلات**: للأنشطة المشبوهة
5. **احفظ نسخ احتياطية**: منتظمة ومشفرة

---

## 🚀 النشر

### النشر على Vercel

#### 1. إعداد المشروع
```bash
# تثبيت Vercel CLI
npm i -g vercel

# تسجيل الدخول
vercel login

# في مجلد المشروع
vercel
```

#### 2. إعداد vercel.json
```json
{
  "version": 2,
  "builds": [
    {
      "src": "backend/src/main.py",
      "use": "@vercel/python"
    },
    {
      "src": "frontend/package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "backend/src/main.py"
    },
    {
      "src": "/(.*)",
      "dest": "frontend/dist/$1"
    }
  ],
  "env": {
    "DISCORD_CLIENT_ID": "@discord_client_id",
    "DISCORD_CLIENT_SECRET": "@discord_client_secret"
  }
}
```

#### 3. إعداد متغيرات البيئة
```bash
vercel env add DISCORD_CLIENT_ID
vercel env add DISCORD_CLIENT_SECRET
vercel env add SECRET_KEY
```

### النشر على Railway

#### 1. إعداد railway.json
```json
{
  "build": {
    "builder": "DOCKERFILE"
  },
  "deploy": {
    "startCommand": "python backend/src/main.py",
    "healthcheckPath": "/api/health"
  }
}
```

#### 2. إعداد Dockerfile
```dockerfile
FROM node:18-alpine AS frontend
WORKDIR /app/frontend
COPY frontend/package*.json ./
RUN npm ci
COPY frontend/ ./
RUN npm run build

FROM python:3.9-slim
WORKDIR /app
COPY backend/requirements.txt ./
RUN pip install -r requirements.txt
COPY backend/ ./
COPY --from=frontend /app/frontend/dist ./static

EXPOSE $PORT
CMD python src/main.py
```

### النشر على VPS

#### 1. إعداد الخادم
```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تثبيت المتطلبات
sudo apt install -y python3 python3-pip nodejs npm docker.io nginx

# تثبيت Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.0.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
```

#### 2. إعداد المشروع
```bash
# استنساخ المشروع
git clone <repository-url>
cd bot-hosting-platform

# إعداد متغيرات البيئة
sudo nano /etc/environment
# أضف المتغيرات المطلوبة

# بناء ونشر
docker-compose -f docker-compose.prod.yml up -d
```

#### 3. إعداد Nginx
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

#### 4. إعداد SSL
```bash
# تثبيت Certbot
sudo apt install certbot python3-certbot-nginx

# الحصول على شهادة SSL
sudo certbot --nginx -d your-domain.com
```

### مراقبة الإنتاج

#### 1. إعداد Logging
```python
import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler(
        'logs/app.log', 
        maxBytes=10240000, 
        backupCount=10
    )
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

#### 2. Health Checks
```python
@app.route('/api/health')
def health_check():
    return {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    }
```

#### 3. Monitoring Scripts
```bash
#!/bin/bash
# monitor.sh - مراقبة حالة الخدمة

while true; do
    if ! curl -f http://localhost:5000/api/health > /dev/null 2>&1; then
        echo "Service is down, restarting..."
        docker-compose restart
        sleep 30
    fi
    sleep 60
done
```

---

## 🤝 المساهمة

### إرشادات المساهمة

#### 1. إعداد بيئة التطوير
```bash
# Fork المشروع
git clone https://github.com/your-username/bot-hosting-platform.git
cd bot-hosting-platform

# إنشاء branch جديد
git checkout -b feature/new-feature

# إعداد البيئة
./setup-dev.sh
```

#### 2. معايير الكود

##### Python (Backend)
- **PEP 8**: اتبع معايير Python
- **Type Hints**: استخدم type hints
- **Docstrings**: وثق الدوال والكلاسات
- **Tests**: اكتب اختبارات للكود الجديد

```python
def create_user(discord_id: str, username: str) -> User:
    """
    إنشاء مستخدم جديد
    
    Args:
        discord_id: معرف Discord الفريد
        username: اسم المستخدم
        
    Returns:
        User: كائن المستخدم المنشأ
        
    Raises:
        ValueError: إذا كان discord_id موجود مسبقاً
    """
    if User.query.filter_by(discord_id=discord_id).first():
        raise ValueError("المستخدم موجود مسبقاً")
    
    user = User(discord_id=discord_id, username=username)
    db.session.add(user)
    db.session.commit()
    return user
```

##### JavaScript (Frontend)
- **ESLint**: استخدم ESLint للتحقق من الكود
- **Prettier**: لتنسيق الكود
- **JSDoc**: وثق الدوال المعقدة
- **PropTypes**: للتحقق من props

```jsx
/**
 * مكون عرض معلومات المستخدم
 * @param {Object} props - خصائص المكون
 * @param {Object} props.user - بيانات المستخدم
 * @param {Function} props.onEdit - دالة التحرير
 */
const UserCard = ({ user, onEdit }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{user.username}</CardTitle>
      </CardHeader>
      <CardContent>
        <p>النقاط: {user.points}</p>
        <Button onClick={() => onEdit(user)}>تحرير</Button>
      </CardContent>
    </Card>
  )
}

UserCard.propTypes = {
  user: PropTypes.shape({
    username: PropTypes.string.isRequired,
    points: PropTypes.number.isRequired
  }).isRequired,
  onEdit: PropTypes.func.isRequired
}
```

#### 3. عملية المراجعة

##### قبل إرسال Pull Request
```bash
# تشغيل الاختبارات
npm test                    # Frontend tests
python -m pytest          # Backend tests

# فحص الكود
npm run lint               # Frontend linting
flake8 backend/           # Backend linting

# بناء المشروع
npm run build             # Frontend build
```

##### معايير Pull Request
1. **عنوان واضح**: وصف مختصر للتغيير
2. **وصف مفصل**: شرح التغييرات والأسباب
3. **اختبارات**: تأكد من وجود اختبارات للكود الجديد
4. **توثيق**: حدث التوثيق إذا لزم الأمر
5. **Screenshots**: للتغييرات في UI

##### مثال على Pull Request
```markdown
## الوصف
إضافة ميزة تصدير بيانات المستخدم

## التغييرات
- إضافة endpoint جديد `/api/user/export`
- إضافة زر التصدير في لوحة التحكم
- إضافة اختبارات للميزة الجديدة

## الاختبار
- [x] اختبار وحدة للـ endpoint
- [x] اختبار تكامل للواجهة
- [x] اختبار يدوي للتأكد من عمل الميزة

## Screenshots
![Export Button](screenshot.png)
```

### هيكل الاختبارات

#### Backend Tests
```python
# tests/test_auth.py
import pytest
from src.main import app, db
from src.models.user import User

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

def test_user_creation(client):
    """اختبار إنشاء مستخدم جديد"""
    user_data = {
        'discord_id': '123456789',
        'username': 'testuser'
    }
    
    response = client.post('/api/auth/create-user', json=user_data)
    assert response.status_code == 201
    
    user = User.query.filter_by(discord_id='123456789').first()
    assert user is not None
    assert user.username == 'testuser'
```

#### Frontend Tests
```jsx
// tests/UserCard.test.jsx
import { render, screen, fireEvent } from '@testing-library/react'
import UserCard from '../src/components/UserCard'

describe('UserCard', () => {
  const mockUser = {
    username: 'testuser',
    points: 100
  }
  
  const mockOnEdit = jest.fn()

  test('يعرض معلومات المستخدم', () => {
    render(<UserCard user={mockUser} onEdit={mockOnEdit} />)
    
    expect(screen.getByText('testuser')).toBeInTheDocument()
    expect(screen.getByText('النقاط: 100')).toBeInTheDocument()
  })

  test('يستدعي onEdit عند الضغط على تحرير', () => {
    render(<UserCard user={mockUser} onEdit={mockOnEdit} />)
    
    fireEvent.click(screen.getByText('تحرير'))
    expect(mockOnEdit).toHaveBeenCalledWith(mockUser)
  })
})
```

### إرشادات الأمان للمساهمين

1. **لا تضع أسرار في الكود**: استخدم متغيرات البيئة
2. **تحقق من المدخلات**: validate جميع البيانات
3. **استخدم parameterized queries**: لتجنب SQL injection
4. **فحص التبعيات**: للثغرات الأمنية
5. **اتبع مبدأ least privilege**: أقل صلاحيات ممكنة

### الحصول على المساعدة

- **Discord Server**: انضم لسيرفر المطورين
- **GitHub Issues**: لطرح الأسئلة والمشاكل
- **Documentation**: راجع التوثيق أولاً
- **Code Review**: اطلب مراجعة من المطورين الآخرين

---

**🎉 شكراً لك على اهتمامك بالمساهمة في تطوير المنصة! كل مساهمة تساعد في تحسين التجربة للجميع.**

