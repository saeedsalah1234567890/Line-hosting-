from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    """نموذج المستخدم"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    discord_id = db.Column(db.String(20), unique=True, nullable=False)
    username = db.Column(db.String(80), nullable=False)
    discriminator = db.Column(db.String(4), nullable=True)
    avatar = db.Column(db.String(100), nullable=True)
    email = db.Column(db.String(120), nullable=True)
    points = db.Column(db.Integer, default=0)
    is_admin = db.Column(db.Boolean, default=False)
    is_banned = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, default=datetime.utcnow)
    last_ad_view = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<User {self.username}#{self.discriminator}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'discord_id': self.discord_id,
            'username': self.username,
            'discriminator': self.discriminator,
            'avatar': self.avatar,
            'email': self.email,
            'points': self.points,
            'is_admin': self.is_admin,
            'is_banned': self.is_banned,
            'created_at': self.created_at.isoformat(),
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
    
    def has_active_subscription(self):
        """التحقق من وجود اشتراك نشط"""
        active_sub = Subscription.query.filter_by(
            user_id=self.id,
            is_active=True
        ).first()
        return active_sub is not None
    
    def get_active_subscription(self):
        """الحصول على الاشتراك النشط"""
        return Subscription.query.filter_by(
            user_id=self.id,
            is_active=True
        ).first()

class PointTransaction(db.Model):
    """معاملات النقاط"""
    __tablename__ = 'point_transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # earned, spent, bonus
    reason = db.Column(db.String(200), nullable=False)
    balance_after = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # العلاقات
    user = db.relationship('User', backref=db.backref('point_transactions', lazy=True))
    
    def __repr__(self):
        return f'<PointTransaction {self.id}: {self.amount} points for user {self.user_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'amount': self.amount,
            'transaction_type': self.transaction_type,
            'reason': self.reason,
            'balance_after': self.balance_after,
            'created_at': self.created_at.isoformat()
        }

class Subscription(db.Model):
    """نموذج الاشتراكات"""
    __tablename__ = 'subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    plan_type = db.Column(db.String(20), nullable=False)  # weekly, monthly
    points_cost = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    cancelled_at = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    auto_renew = db.Column(db.Boolean, default=True)
    
    # العلاقات
    user = db.relationship('User', backref=db.backref('subscriptions', lazy=True))
    
    def __repr__(self):
        return f'<Subscription {self.id}: {self.plan_type} for user {self.user_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'plan_type': self.plan_type,
            'points_cost': self.points_cost,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat(),
            'cancelled_at': self.cancelled_at.isoformat() if self.cancelled_at else None,
            'is_active': self.is_active,
            'auto_renew': self.auto_renew
        }
    
    def is_expired(self):
        """التحقق من انتهاء الاشتراك"""
        return datetime.utcnow() > self.expires_at
    
    def days_remaining(self):
        """عدد الأيام المتبقية في الاشتراك"""
        if self.is_expired():
            return 0
        time_diff = self.expires_at - datetime.utcnow()
        return time_diff.days

class Hosting(db.Model):
    """استضافات البوتات"""
    __tablename__ = 'hostings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    subscription_id = db.Column(db.Integer, db.ForeignKey('subscriptions.id'), nullable=False)
    bot_name = db.Column(db.String(100), nullable=False)
    language = db.Column(db.String(20), nullable=False)  # nodejs, python, java, php, bash
    container_id = db.Column(db.String(100), nullable=True)
    status = db.Column(db.String(20), default='stopped')  # running, stopped, error
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_started = db.Column(db.DateTime, nullable=True)
    last_stopped = db.Column(db.DateTime, nullable=True)
    cpu_limit = db.Column(db.String(10), default='0.5')  # CPU limit
    memory_limit = db.Column(db.String(10), default='512m')  # Memory limit
    storage_used = db.Column(db.Integer, default=0)  # Storage used in MB
    
    # العلاقات
    user = db.relationship('User', backref=db.backref('hostings', lazy=True))
    subscription = db.relationship('Subscription', backref=db.backref('hostings', lazy=True))
    
    def __repr__(self):
        return f'<Hosting {self.id}: {self.bot_name} ({self.language}) for user {self.user_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'subscription_id': self.subscription_id,
            'bot_name': self.bot_name,
            'language': self.language,
            'container_id': self.container_id,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'last_started': self.last_started.isoformat() if self.last_started else None,
            'last_stopped': self.last_stopped.isoformat() if self.last_stopped else None,
            'cpu_limit': self.cpu_limit,
            'memory_limit': self.memory_limit,
            'storage_used': self.storage_used
        }

class ActivityLog(db.Model):
    """سجل الأنشطة"""
    __tablename__ = 'activity_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # العلاقات
    user = db.relationship('User', backref=db.backref('activity_logs', lazy=True))
    
    def __repr__(self):
        return f'<ActivityLog {self.id}: {self.action} by user {self.user_id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'action': self.action,
            'description': self.description,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'created_at': self.created_at.isoformat()
        }

