import os
from datetime import timedelta
from pathlib import Path

class Config:
    """إعدادات التطبيق الأساسية"""
    
    # المسار الأساسي للمشروع
    BASE_DIR = Path(__file__).parent.parent.absolute()
    
    # إعدادات التطبيق الأساسية
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or 'dev-jwt-secret-change-in-production'
    
    # إعدادات Discord OAuth
    DISCORD_CLIENT_ID = os.environ.get('DISCORD_CLIENT_ID')
    DISCORD_CLIENT_SECRET = os.environ.get('DISCORD_CLIENT_SECRET')
    DISCORD_REDIRECT_URI = os.environ.get('DISCORD_REDIRECT_URI') or 'http://localhost:5000/api/auth/callback'
    
    # إعدادات قاعدة البيانات
    DATABASE_URL = os.environ.get('DATABASE_URL') or f'sqlite:///{BASE_DIR}/database/app.db'
    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # إعدادات الإعلانات
    AD_POINTS_PER_VIEW = int(os.environ.get('AD_POINTS_PER_VIEW', '3'))
    AD_COOLDOWN_SECONDS = int(os.environ.get('AD_COOLDOWN_SECONDS', '60'))
    
    # إعدادات الاشتراكات
    WEEKLY_SUBSCRIPTION_POINTS = int(os.environ.get('WEEKLY_SUBSCRIPTION_POINTS', '15'))
    MONTHLY_SUBSCRIPTION_POINTS = int(os.environ.get('MONTHLY_SUBSCRIPTION_POINTS', '60'))
    
    # إعدادات Docker
    DOCKER_HOST = os.environ.get('DOCKER_HOST') or 'unix:///var/run/docker.sock'
    BOT_CONTAINERS_PREFIX = os.environ.get('BOT_CONTAINERS_PREFIX') or 'bothost_'
    
    # إعدادات الأمان والمشرفين
    ADMIN_DISCORD_IDS = os.environ.get('ADMIN_DISCORD_IDS', '').split(',') if os.environ.get('ADMIN_DISCORD_IDS') else []
    BOT_API_TOKEN = os.environ.get('BOT_API_TOKEN') or 'dev-bot-token-change-in-production'
    
    # إعدادات CORS
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', 'http://localhost:3000,http://localhost:5173').split(',')
    
    # إعدادات الملفات
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER') or '/tmp/bot_files'
    MAX_CONTENT_LENGTH = int(os.environ.get('MAX_CONTENT_LENGTH', str(16 * 1024 * 1024)))  # 16MB
    
    # إعدادات JWT
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=int(os.environ.get('JWT_EXPIRES_DAYS', '7')))
    
    @staticmethod
    def init_app(app):
        """تهيئة التطبيق مع الإعدادات"""
        pass

class DevelopmentConfig(Config):
    """إعدادات التطوير"""
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    """إعدادات الإنتاج"""
    DEBUG = False
    TESTING = False
    
    @staticmethod
    def init_app(app):
        Config.init_app(app)
        
        # تسجيل الأخطاء في الإنتاج
        import logging
        from logging.handlers import RotatingFileHandler
        
        if not app.debug and not app.testing:
            if not os.path.exists('logs'):
                os.mkdir('logs')
            
            file_handler = RotatingFileHandler(
                'logs/bot_hosting.log',
                maxBytes=10240000,
                backupCount=10
            )
            file_handler.setFormatter(logging.Formatter(
                '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
            ))
            file_handler.setLevel(logging.INFO)
            app.logger.addHandler(file_handler)
            app.logger.setLevel(logging.INFO)
            app.logger.info('Bot Hosting Platform startup')

class TestingConfig(Config):
    """إعدادات الاختبار"""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    WTF_CSRF_ENABLED = False

# تحديد التكوين بناءً على متغير البيئة
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

def get_config():
    """الحصول على التكوين المناسب"""
    env = os.environ.get('FLASK_ENV', 'development')
    return config.get(env, config['default'])

def validate_config():
    """التحقق من صحة الإعدادات المطلوبة"""
    required_vars = [
        'DISCORD_CLIENT_ID',
        'DISCORD_CLIENT_SECRET'
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.environ.get(var):
            missing_vars.append(var)
    
    if missing_vars:
        raise ValueError(f"متغيرات البيئة المطلوبة غير موجودة: {', '.join(missing_vars)}")
    
    return True

