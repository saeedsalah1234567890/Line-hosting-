from flask import Blueprint, request, jsonify, redirect, current_app, session
import requests
import jwt
from datetime import datetime, timedelta
from src.models.user import User, ActivityLog, db
from functools import wraps

auth_bp = Blueprint('auth', __name__)

def is_admin_discord_id(discord_id):
    """التحقق من كون Discord ID في قائمة المشرفين"""
    admin_ids = current_app.config.get('ADMIN_DISCORD_IDS', [])
    return discord_id in admin_ids

def token_required(f):
    """ديكوريتر للتحقق من صحة التوكن"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'error': 'Token is missing'}), 401
        
        try:
            if token.startswith('Bearer '):
                token = token[7:]
            data = jwt.decode(token, current_app.config['JWT_SECRET_KEY'], algorithms=['HS256'])
            current_user = User.query.get(data['user_id'])
            if not current_user:
                return jsonify({'error': 'User not found'}), 401
            if current_user.is_banned:
                return jsonify({'error': 'User is banned'}), 403
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Token is invalid'}), 401
        
        return f(current_user, *args, **kwargs)
    return decorated

def admin_required(f):
    """ديكوريتر للتحقق من صلاحيات المشرف"""
    @wraps(f)
    def decorated(current_user, *args, **kwargs):
        if not current_user.is_admin:
            return jsonify({'error': 'Admin access required'}), 403
        return f(current_user, *args, **kwargs)
    return decorated

@auth_bp.route('/login')
def login():
    """بدء عملية تسجيل الدخول مع Discord"""
    discord_auth_url = (
        f"https://discord.com/api/oauth2/authorize?"
        f"client_id={current_app.config['DISCORD_CLIENT_ID']}&"
        f"redirect_uri={current_app.config['DISCORD_REDIRECT_URI']}&"
        f"response_type=code&"
        f"scope=identify%20email"
    )
    return redirect(discord_auth_url)

@auth_bp.route('/callback')
def callback():
    """معالجة استجابة Discord OAuth"""
    code = request.args.get('code')
    if not code:
        return jsonify({'error': 'Authorization code not provided'}), 400
    
    try:
        # الحصول على access token من Discord
        token_data = {
            'client_id': current_app.config['DISCORD_CLIENT_ID'],
            'client_secret': current_app.config['DISCORD_CLIENT_SECRET'],
            'grant_type': 'authorization_code',
            'code': code,
            'redirect_uri': current_app.config['DISCORD_REDIRECT_URI']
        }
        
        token_response = requests.post(
            'https://discord.com/api/oauth2/token',
            data=token_data,
            headers={'Content-Type': 'application/x-www-form-urlencoded'}
        )
        
        if token_response.status_code != 200:
            return jsonify({'error': 'Failed to get access token'}), 400
        
        token_json = token_response.json()
        access_token = token_json['access_token']
        
        # الحصول على معلومات المستخدم من Discord
        user_response = requests.get(
            'https://discord.com/api/users/@me',
            headers={'Authorization': f'Bearer {access_token}'}
        )
        
        if user_response.status_code != 200:
            return jsonify({'error': 'Failed to get user info'}), 400
        
        discord_user = user_response.json()
        
        # البحث عن المستخدم في قاعدة البيانات أو إنشاؤه
        user = User.query.filter_by(discord_id=discord_user['id']).first()
        
        # التحقق من كون المستخدم مشرف تلقائي
        is_auto_admin = is_admin_discord_id(discord_user['id'])
        
        if not user:
            # إنشاء مستخدم جديد
            user = User(
                discord_id=discord_user['id'],
                username=discord_user['username'],
                discriminator=discord_user.get('discriminator'),
                avatar=discord_user.get('avatar'),
                email=discord_user.get('email'),
                points=100,  # نقاط البداية
                is_admin=is_auto_admin  # منح صلاحيات المشرف تلقائياً إذا كان في القائمة
            )
            db.session.add(user)
            
            # تسجيل نشاط إنشاء حساب جديد
            log_description = 'تم إنشاء حساب جديد'
            if is_auto_admin:
                log_description += ' مع صلاحيات المشرف التلقائية'
            
            log = ActivityLog(
                user_id=user.id,
                action='account_created',
                description=log_description,
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            db.session.add(log)
        else:
            # تحديث معلومات المستخدم الموجود
            user.username = discord_user['username']
            user.discriminator = discord_user.get('discriminator')
            user.avatar = discord_user.get('avatar')
            user.email = discord_user.get('email')
            user.last_login = datetime.utcnow()
            
            # التحقق من تحديث صلاحيات المشرف
            if is_auto_admin and not user.is_admin:
                user.is_admin = True
                # تسجيل منح صلاحيات المشرف
                admin_log = ActivityLog(
                    user_id=user.id,
                    action='auto_admin_granted',
                    description='تم منح صلاحيات المشرف تلقائياً بناءً على Discord ID',
                    ip_address=request.remote_addr,
                    user_agent=request.headers.get('User-Agent')
                )
                db.session.add(admin_log)
            
            # تسجيل نشاط تسجيل الدخول
            log = ActivityLog(
                user_id=user.id,
                action='login',
                description='تم تسجيل الدخول',
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            db.session.add(log)
        
        db.session.commit()
        
        # إنشاء JWT token
        payload = {
            'user_id': user.id,
            'discord_id': user.discord_id,
            'is_admin': user.is_admin,
            'exp': datetime.utcnow() + current_app.config['JWT_ACCESS_TOKEN_EXPIRES']
        }
        
        jwt_token = jwt.encode(payload, current_app.config['JWT_SECRET_KEY'], algorithm='HS256')
        
        # تحديد URL الواجهة الأمامية
        frontend_url = request.args.get('redirect_uri')
        if not frontend_url:
            # استخدام URL افتراضي بناءً على البيئة
            if current_app.config['DEBUG']:
                frontend_url = "http://localhost:3000/auth/success"
            else:
                # في الإنتاج، استخدم نفس النطاق
                frontend_url = f"{request.scheme}://{request.host}/auth/success"
        
        return redirect(f"{frontend_url}?token={jwt_token}")
        
    except Exception as e:
        current_app.logger.error(f"OAuth callback error: {str(e)}")
        return jsonify({'error': 'Authentication failed'}), 500

@auth_bp.route('/me')
@token_required
def get_current_user(current_user):
    """الحصول على معلومات المستخدم الحالي"""
    return jsonify(current_user.to_dict())

@auth_bp.route('/logout')
@token_required
def logout(current_user):
    """تسجيل الخروج"""
    # تسجيل نشاط تسجيل الخروج
    log = ActivityLog(
        user_id=current_user.id,
        action='logout',
        description='تم تسجيل الخروج',
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(log)
    db.session.commit()
    
    return jsonify({'message': 'Logged out successfully'})

@auth_bp.route('/refresh')
@token_required
def refresh_token(current_user):
    """تجديد التوكن"""
    payload = {
        'user_id': current_user.id,
        'discord_id': current_user.discord_id,
        'is_admin': current_user.is_admin,
        'exp': datetime.utcnow() + current_app.config['JWT_ACCESS_TOKEN_EXPIRES']
    }
    
    new_token = jwt.encode(payload, current_app.config['JWT_SECRET_KEY'], algorithm='HS256')
    
    return jsonify({'token': new_token})

@auth_bp.route('/check-admin')
@token_required
def check_admin_status(current_user):
    """التحقق من صلاحيات المشرف للمستخدم الحالي"""
    return jsonify({
        'is_admin': current_user.is_admin,
        'discord_id': current_user.discord_id,
        'username': current_user.username
    })



def admin_required(f):
    """Decorator للتحقق من صلاحيات المشرف"""
    from functools import wraps
    
    @wraps(f)
    def decorated_function(current_user, *args, **kwargs):
        if not current_user.is_admin:
            return jsonify({'error': 'صلاحيات المشرف مطلوبة'}), 403
        return f(current_user, *args, **kwargs)
    
    return decorated_function

