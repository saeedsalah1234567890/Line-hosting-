from flask import Blueprint, request, jsonify, current_app
from datetime import datetime
from src.models.user import User, Hosting, Subscription, ActivityLog, db
from src.routes.auth import token_required
import docker
import os
import shutil
import zipfile
import tempfile
import json
import subprocess
import threading
import time

hosting_bp = Blueprint('hosting', __name__)

# إعداد Docker client
try:
    docker_client = docker.from_env()
except Exception as e:
    docker_client = None
    print(f"Warning: Docker not available: {e}")

# قوالب البوتات للغات المختلفة
BOT_TEMPLATES = {
    'nodejs': {
        'name': 'Node.js Bot',
        'dockerfile': '''FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]''',
        'package_json': '''{
  "name": "discord-bot",
  "version": "1.0.0",
  "description": "Discord Bot",
  "main": "index.js",
  "scripts": {
    "start": "node index.js"
  },
  "dependencies": {
    "discord.js": "^14.0.0"
  }
}''',
        'main_file': '''const { Client, GatewayIntentBits } = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('messageCreate', message => {
    if (message.content === '!ping') {
        message.reply('Pong!');
    }
});

client.login(process.env.DISCORD_TOKEN);''',
        'file_name': 'index.js'
    },
    'python': {
        'name': 'Python Bot',
        'dockerfile': '''FROM python:3.11-alpine
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "main.py"]''',
        'requirements': '''discord.py==2.3.2
python-dotenv==1.0.0''',
        'main_file': '''import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

load_dotenv()

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')

@bot.command(name='ping')
async def ping(ctx):
    await ctx.send('Pong!')

bot.run(os.getenv('DISCORD_TOKEN'))''',
        'file_name': 'main.py'
    },
    'java': {
        'name': 'Java Bot',
        'dockerfile': '''FROM openjdk:17-alpine
WORKDIR /app
COPY . .
RUN javac -cp ".:lib/*" *.java
CMD ["java", "-cp", ".:lib/*", "Main"]''',
        'main_file': '''import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Main extends ListenerAdapter {
    public static void main(String[] args) throws Exception {
        String token = System.getenv("DISCORD_TOKEN");
        JDA jda = JDABuilder.createDefault(token)
                .addEventListeners(new Main())
                .build();
        jda.awaitReady();
    }

    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        if (event.getMessage().getContentRaw().equals("!ping")) {
            event.getChannel().sendMessage("Pong!").queue();
        }
    }
}''',
        'file_name': 'Main.java'
    },
    'php': {
        'name': 'PHP Bot',
        'dockerfile': '''FROM php:8.2-cli
WORKDIR /app
COPY . .
RUN apt-get update && apt-get install -y git unzip
RUN curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
RUN composer install
CMD ["php", "bot.php"]''',
        'composer_json': '''{
    "require": {
        "team-reflex/discord-php": "^7.0"
    }
}''',
        'main_file': '''<?php
require_once 'vendor/autoload.php';

use Discord\\Discord;
use Discord\\Parts\\Channel\\Message;

$discord = new Discord([
    'token' => $_ENV['DISCORD_TOKEN'],
]);

$discord->on('ready', function ($discord) {
    echo "Bot is ready!", PHP_EOL;
});

$discord->on('message', function ($message, $discord) {
    if ($message->content == '!ping') {
        $message->reply('Pong!');
    }
});

$discord->run();
?>''',
        'file_name': 'bot.php'
    },
    'bash': {
        'name': 'Bash Bot',
        'dockerfile': '''FROM alpine:latest
RUN apk add --no-cache bash curl jq
WORKDIR /app
COPY . .
RUN chmod +x bot.sh
CMD ["./bot.sh"]''',
        'main_file': '''#!/bin/bash

DISCORD_TOKEN="${DISCORD_TOKEN}"
BOT_ID="YOUR_BOT_ID"

echo "Starting Bash Discord Bot..."

while true; do
    echo "Bot is running... (This is a simple example)"
    sleep 60
done''',
        'file_name': 'bot.sh'
    }
}

@hosting_bp.route('/languages')
def get_supported_languages():
    """الحصول على اللغات المدعومة"""
    languages = []
    for lang_id, template in BOT_TEMPLATES.items():
        languages.append({
            'id': lang_id,
            'name': template['name'],
            'icon': lang_id,
            'description': f'إنشاء بوت باستخدام {template["name"]}'
        })
    
    return jsonify({'languages': languages})

@hosting_bp.route('/my-bots')
@token_required
def get_user_bots(current_user):
    """الحصول على بوتات المستخدم"""
    try:
        # التحقق من وجود اشتراك نشط
        if not current_user.has_active_subscription():
            return jsonify({'error': 'تحتاج إلى اشتراك نشط لعرض البوتات'}), 403
        
        hostings = Hosting.query.filter_by(user_id=current_user.id).all()
        
        bots = []
        for hosting in hostings:
            bot_data = hosting.to_dict()
            
            # إضافة معلومات إضافية عن حالة الحاوية
            if hosting.container_id and docker_client:
                try:
                    container = docker_client.containers.get(hosting.container_id)
                    bot_data['container_status'] = container.status
                    bot_data['container_health'] = container.attrs.get('State', {}).get('Health', {}).get('Status', 'unknown')
                except:
                    bot_data['container_status'] = 'not_found'
                    bot_data['container_health'] = 'unknown'
            
            bots.append(bot_data)
        
        return jsonify({'bots': bots})
        
    except Exception as e:
        current_app.logger.error(f"Error fetching user bots: {str(e)}")
        return jsonify({'error': 'Failed to fetch bots'}), 500

@hosting_bp.route('/create', methods=['POST'])
@token_required
def create_bot(current_user):
    """إنشاء بوت جديد"""
    try:
        # التحقق من وجود اشتراك نشط
        if not current_user.has_active_subscription():
            return jsonify({'error': 'تحتاج إلى اشتراك نشط لإنشاء بوت'}), 403
        
        data = request.get_json()
        bot_name = data.get('bot_name', '').strip()
        language = data.get('language', '').strip()
        
        if not bot_name or not language:
            return jsonify({'error': 'اسم البوت واللغة مطلوبان'}), 400
        
        if language not in BOT_TEMPLATES:
            return jsonify({'error': 'اللغة غير مدعومة'}), 400
        
        # التحقق من عدم وجود بوت بنفس الاسم للمستخدم
        existing_bot = Hosting.query.filter_by(
            user_id=current_user.id,
            bot_name=bot_name
        ).first()
        
        if existing_bot:
            return jsonify({'error': 'يوجد بوت بنفس الاسم بالفعل'}), 400
        
        # الحصول على الاشتراك النشط
        subscription = current_user.get_active_subscription()
        
        # إنشاء سجل الاستضافة
        hosting = Hosting(
            user_id=current_user.id,
            subscription_id=subscription.id,
            bot_name=bot_name,
            language=language,
            status='stopped'
        )
        
        db.session.add(hosting)
        db.session.commit()
        
        # إنشاء مجلد البوت وملفاته
        bot_dir = create_bot_files(hosting.id, language, bot_name)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='bot_created',
            description=f'تم إنشاء بوت {bot_name} بلغة {language}',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم إنشاء البوت {bot_name} بنجاح',
            'bot': hosting.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error creating bot: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إنشاء البوت'}), 500

@hosting_bp.route('/<int:bot_id>/start', methods=['POST'])
@token_required
def start_bot(current_user, bot_id):
    """تشغيل البوت"""
    try:
        hosting = Hosting.query.filter_by(id=bot_id, user_id=current_user.id).first()
        
        if not hosting:
            return jsonify({'error': 'البوت غير موجود'}), 404
        
        # التحقق من وجود اشتراك نشط
        if not current_user.has_active_subscription():
            return jsonify({'error': 'تحتاج إلى اشتراك نشط لتشغيل البوت'}), 403
        
        if not docker_client:
            return jsonify({'error': 'خدمة Docker غير متاحة'}), 503
        
        # إيقاف الحاوية إذا كانت تعمل
        if hosting.container_id:
            try:
                container = docker_client.containers.get(hosting.container_id)
                if container.status == 'running':
                    container.stop()
                container.remove()
            except:
                pass
        
        # بناء وتشغيل الحاوية الجديدة
        bot_dir = get_bot_directory(hosting.id)
        container_name = f"bothost_{hosting.id}_{hosting.user_id}"
        
        # بناء الصورة
        image_tag = f"bot_{hosting.id}"
        docker_client.images.build(
            path=bot_dir,
            tag=image_tag,
            rm=True
        )
        
        # تشغيل الحاوية
        container = docker_client.containers.run(
            image_tag,
            name=container_name,
            detach=True,
            environment={
                'DISCORD_TOKEN': 'YOUR_BOT_TOKEN_HERE'
            },
            mem_limit=hosting.memory_limit,
            cpu_period=100000,
            cpu_quota=int(float(hosting.cpu_limit) * 100000),
            restart_policy={"Name": "unless-stopped"}
        )
        
        # تحديث معلومات الاستضافة
        hosting.container_id = container.id
        hosting.status = 'running'
        hosting.last_started = datetime.utcnow()
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='bot_started',
            description=f'تم تشغيل البوت {hosting.bot_name}',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم تشغيل البوت {hosting.bot_name} بنجاح',
            'container_id': container.id
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error starting bot: {str(e)}")
        return jsonify({'error': f'حدث خطأ أثناء تشغيل البوت: {str(e)}'}), 500

@hosting_bp.route('/<int:bot_id>/stop', methods=['POST'])
@token_required
def stop_bot(current_user, bot_id):
    """إيقاف البوت"""
    try:
        hosting = Hosting.query.filter_by(id=bot_id, user_id=current_user.id).first()
        
        if not hosting:
            return jsonify({'error': 'البوت غير موجود'}), 404
        
        if not hosting.container_id:
            return jsonify({'error': 'البوت غير مشغل'}), 400
        
        if not docker_client:
            return jsonify({'error': 'خدمة Docker غير متاحة'}), 503
        
        # إيقاف الحاوية
        try:
            container = docker_client.containers.get(hosting.container_id)
            container.stop(timeout=10)
            
            hosting.status = 'stopped'
            hosting.last_stopped = datetime.utcnow()
            
            # تسجيل النشاط
            log = ActivityLog(
                user_id=current_user.id,
                action='bot_stopped',
                description=f'تم إيقاف البوت {hosting.bot_name}',
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            db.session.add(log)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': f'تم إيقاف البوت {hosting.bot_name} بنجاح'
            })
            
        except docker.errors.NotFound:
            hosting.status = 'stopped'
            hosting.container_id = None
            db.session.commit()
            return jsonify({'error': 'الحاوية غير موجودة'}), 404
            
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error stopping bot: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إيقاف البوت'}), 500

@hosting_bp.route('/<int:bot_id>/restart', methods=['POST'])
@token_required
def restart_bot(current_user, bot_id):
    """إعادة تشغيل البوت"""
    try:
        # إيقاف البوت أولاً
        stop_response = stop_bot(current_user, bot_id)
        if stop_response[1] != 200:
            return stop_response
        
        # انتظار قصير
        time.sleep(2)
        
        # تشغيل البوت مرة أخرى
        return start_bot(current_user, bot_id)
        
    except Exception as e:
        current_app.logger.error(f"Error restarting bot: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إعادة تشغيل البوت'}), 500

@hosting_bp.route('/<int:bot_id>/logs')
@token_required
def get_bot_logs(current_user, bot_id):
    """الحصول على سجلات البوت"""
    try:
        hosting = Hosting.query.filter_by(id=bot_id, user_id=current_user.id).first()
        
        if not hosting:
            return jsonify({'error': 'البوت غير موجود'}), 404
        
        if not hosting.container_id:
            return jsonify({'logs': 'البوت غير مشغل حالياً'})
        
        if not docker_client:
            return jsonify({'error': 'خدمة Docker غير متاحة'}), 503
        
        try:
            container = docker_client.containers.get(hosting.container_id)
            logs = container.logs(tail=100, timestamps=True).decode('utf-8')
            
            return jsonify({'logs': logs})
            
        except docker.errors.NotFound:
            return jsonify({'logs': 'الحاوية غير موجودة'})
            
    except Exception as e:
        current_app.logger.error(f"Error fetching bot logs: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء جلب السجلات'}), 500

@hosting_bp.route('/<int:bot_id>/files')
@token_required
def get_bot_files(current_user, bot_id):
    """الحصول على ملفات البوت"""
    try:
        hosting = Hosting.query.filter_by(id=bot_id, user_id=current_user.id).first()
        
        if not hosting:
            return jsonify({'error': 'البوت غير موجود'}), 404
        
        bot_dir = get_bot_directory(hosting.id)
        
        if not os.path.exists(bot_dir):
            return jsonify({'error': 'مجلد البوت غير موجود'}), 404
        
        files = []
        for root, dirs, filenames in os.walk(bot_dir):
            for filename in filenames:
                file_path = os.path.join(root, filename)
                relative_path = os.path.relpath(file_path, bot_dir)
                
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                except:
                    content = '[ملف ثنائي - لا يمكن عرضه]'
                
                files.append({
                    'name': filename,
                    'path': relative_path,
                    'content': content,
                    'size': os.path.getsize(file_path)
                })
        
        return jsonify({'files': files})
        
    except Exception as e:
        current_app.logger.error(f"Error fetching bot files: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء جلب الملفات'}), 500

@hosting_bp.route('/<int:bot_id>/files/<path:file_path>', methods=['PUT'])
@token_required
def update_bot_file(current_user, bot_id, file_path):
    """تحديث ملف البوت"""
    try:
        hosting = Hosting.query.filter_by(id=bot_id, user_id=current_user.id).first()
        
        if not hosting:
            return jsonify({'error': 'البوت غير موجود'}), 404
        
        data = request.get_json()
        content = data.get('content', '')
        
        bot_dir = get_bot_directory(hosting.id)
        full_file_path = os.path.join(bot_dir, file_path)
        
        # التأكد من أن المسار آمن
        if not full_file_path.startswith(bot_dir):
            return jsonify({'error': 'مسار الملف غير صحيح'}), 400
        
        # إنشاء المجلدات إذا لم تكن موجودة
        os.makedirs(os.path.dirname(full_file_path), exist_ok=True)
        
        # كتابة الملف
        with open(full_file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='bot_file_updated',
            description=f'تم تحديث الملف {file_path} في البوت {hosting.bot_name}',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم تحديث الملف {file_path} بنجاح'
        })
        
    except Exception as e:
        current_app.logger.error(f"Error updating bot file: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء تحديث الملف'}), 500

@hosting_bp.route('/<int:bot_id>/upload', methods=['POST'])
@token_required
def upload_bot_files(current_user, bot_id):
    """رفع ملفات البوت"""
    try:
        hosting = Hosting.query.filter_by(id=bot_id, user_id=current_user.id).first()
        
        if not hosting:
            return jsonify({'error': 'البوت غير موجود'}), 404
        
        if 'file' not in request.files:
            return jsonify({'error': 'لم يتم رفع أي ملف'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'لم يتم اختيار ملف'}), 400
        
        bot_dir = get_bot_directory(hosting.id)
        
        # إذا كان الملف zip، استخراجه
        if file.filename.endswith('.zip'):
            with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as temp_file:
                file.save(temp_file.name)
                
                with zipfile.ZipFile(temp_file.name, 'r') as zip_ref:
                    zip_ref.extractall(bot_dir)
                
                os.unlink(temp_file.name)
        else:
            # حفظ الملف مباشرة
            file_path = os.path.join(bot_dir, file.filename)
            file.save(file_path)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='bot_files_uploaded',
            description=f'تم رفع ملفات إلى البوت {hosting.bot_name}',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم رفع الملفات بنجاح'
        })
        
    except Exception as e:
        current_app.logger.error(f"Error uploading bot files: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء رفع الملفات'}), 500

@hosting_bp.route('/<int:bot_id>/delete', methods=['DELETE'])
@token_required
def delete_bot(current_user, bot_id):
    """حذف البوت"""
    try:
        hosting = Hosting.query.filter_by(id=bot_id, user_id=current_user.id).first()
        
        if not hosting:
            return jsonify({'error': 'البوت غير موجود'}), 404
        
        # إيقاف وحذف الحاوية إذا كانت موجودة
        if hosting.container_id and docker_client:
            try:
                container = docker_client.containers.get(hosting.container_id)
                container.stop(timeout=10)
                container.remove()
            except:
                pass
        
        # حذف ملفات البوت
        bot_dir = get_bot_directory(hosting.id)
        if os.path.exists(bot_dir):
            shutil.rmtree(bot_dir)
        
        # حذف سجل الاستضافة
        db.session.delete(hosting)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='bot_deleted',
            description=f'تم حذف البوت {hosting.bot_name}',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم حذف البوت {hosting.bot_name} بنجاح'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting bot: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء حذف البوت'}), 500

def create_bot_files(hosting_id, language, bot_name):
    """إنشاء ملفات البوت"""
    bot_dir = get_bot_directory(hosting_id)
    os.makedirs(bot_dir, exist_ok=True)
    
    template = BOT_TEMPLATES[language]
    
    # إنشاء Dockerfile
    with open(os.path.join(bot_dir, 'Dockerfile'), 'w') as f:
        f.write(template['dockerfile'])
    
    # إنشاء الملف الرئيسي
    with open(os.path.join(bot_dir, template['file_name']), 'w') as f:
        f.write(template['main_file'])
    
    # إنشاء ملفات إضافية حسب اللغة
    if language == 'nodejs' and 'package_json' in template:
        with open(os.path.join(bot_dir, 'package.json'), 'w') as f:
            f.write(template['package_json'])
    
    elif language == 'python' and 'requirements' in template:
        with open(os.path.join(bot_dir, 'requirements.txt'), 'w') as f:
            f.write(template['requirements'])
    
    elif language == 'php' and 'composer_json' in template:
        with open(os.path.join(bot_dir, 'composer.json'), 'w') as f:
            f.write(template['composer_json'])
    
    # إنشاء ملف README
    readme_content = f"""# {bot_name}

هذا بوت Discord تم إنشاؤه باستخدام {template['name']}.

## التشغيل

1. قم بتعديل ملف البوت الرئيسي
2. أضف توكن البوت في متغيرات البيئة
3. اضغط على زر "تشغيل" في لوحة التحكم

## الملفات

- `{template['file_name']}`: الملف الرئيسي للبوت
- `Dockerfile`: ملف إعداد الحاوية
- `README.md`: هذا الملف

## المساعدة

إذا كنت تحتاج مساعدة، يرجى مراجعة الوثائق أو


التواصل مع الدعم الفني.
"""
    
    with open(os.path.join(bot_dir, 'README.md'), 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    return bot_dir

def get_bot_directory(hosting_id):
    """الحصول على مسار مجلد البوت"""
    base_dir = current_app.config.get('UPLOAD_FOLDER', '/tmp/bot_files')
    return os.path.join(base_dir, f'bot_{hosting_id}')

def cleanup_inactive_containers():
    """تنظيف الحاويات غير النشطة"""
    try:
        if not docker_client:
            return
        
        with current_app.app_context():
            # البحث عن الاستضافات التي لها حاويات ولكن الاشتراك منتهي
            expired_hostings = db.session.query(Hosting).join(Subscription).filter(
                Hosting.container_id.isnot(None),
                Subscription.is_active == False
            ).all()
            
            for hosting in expired_hostings:
                try:
                    container = docker_client.containers.get(hosting.container_id)
                    container.stop(timeout=10)
                    container.remove()
                    
                    hosting.status = 'stopped'
                    hosting.container_id = None
                    
                    current_app.logger.info(f"Cleaned up container for expired hosting {hosting.id}")
                    
                except docker.errors.NotFound:
                    hosting.container_id = None
                except Exception as e:
                    current_app.logger.error(f"Error cleaning up container {hosting.container_id}: {str(e)}")
            
            db.session.commit()
            
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error in cleanup_inactive_containers: {str(e)}")

def start_container_monitor():
    """بدء مراقب الحاويات"""
    def monitor():
        while True:
            try:
                cleanup_inactive_containers()
                time.sleep(600)  # فحص كل 10 دقائق
            except Exception as e:
                current_app.logger.error(f"Container monitor error: {str(e)}")
                time.sleep(60)  # انتظار دقيقة في حالة الخطأ
    
    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()
    current_app.logger.info("Container monitor started")

