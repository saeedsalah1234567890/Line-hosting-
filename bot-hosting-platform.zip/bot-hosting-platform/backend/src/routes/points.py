from flask import Blueprint, request, jsonify, current_app
from datetime import datetime, timedelta
from src.models.user import User, PointTransaction, ActivityLog, db
from src.routes.auth import token_required
import time

points_bp = Blueprint('points', __name__)

@points_bp.route('/balance')
@token_required
def get_balance(current_user):
    """الحصول على رصيد النقاط الحالي"""
    return jsonify({
        'points': current_user.points,
        'user_id': current_user.id,
        'username': current_user.username
    })

@points_bp.route('/history')
@token_required
def get_points_history(current_user):
    """الحصول على تاريخ النقاط"""
    try:
        # الحصول على آخر 50 معاملة
        transactions = PointTransaction.query.filter_by(
            user_id=current_user.id
        ).order_by(PointTransaction.created_at.desc()).limit(50).all()
        
        history = []
        for transaction in transactions:
            # تحديد نوع العمل بناءً على السبب
            action = 'other'
            if 'إعلان' in transaction.reason:
                action = 'ad_watched'
            elif 'اشتراك' in transaction.reason:
                action = 'subscription_purchase'
            elif 'مكافأة' in transaction.reason or 'بوت' in transaction.reason:
                action = 'bonus'
            elif 'إنشاء' in transaction.reason:
                action = 'account_created'
            
            history.append({
                'id': transaction.id,
                'action': action,
                'points_change': transaction.amount if transaction.transaction_type == 'earned' else -transaction.amount,
                'balance_after': transaction.balance_after,
                'description': transaction.reason,
                'created_at': transaction.created_at.isoformat()
            })
        
        return jsonify(history)
        
    except Exception as e:
        current_app.logger.error(f"Error fetching points history: {str(e)}")
        return jsonify({'error': 'Failed to fetch points history'}), 500

@points_bp.route('/ad-status')
@token_required
def get_ad_status(current_user):
    """التحقق من حالة الإعلانات"""
    try:
        cooldown_seconds = current_app.config.get('AD_COOLDOWN_SECONDS', 60)
        
        if not current_user.last_ad_watch:
            # لم يشاهد أي إعلان من قبل
            return jsonify({
                'canWatch': True,
                'cooldownRemaining': 0,
                'isWatching': False,
                'nextAdTime': None
            })
        
        # حساب الوقت المتبقي
        time_since_last_ad = datetime.utcnow() - current_user.last_ad_watch
        cooldown_remaining = max(0, cooldown_seconds - int(time_since_last_ad.total_seconds()))
        
        return jsonify({
            'canWatch': cooldown_remaining == 0,
            'cooldownRemaining': cooldown_remaining,
            'isWatching': False,
            'nextAdTime': (current_user.last_ad_watch + timedelta(seconds=cooldown_seconds)).isoformat() if cooldown_remaining > 0 else None
        })
        
    except Exception as e:
        current_app.logger.error(f"Error checking ad status: {str(e)}")
        return jsonify({'error': 'Failed to check ad status'}), 500

@points_bp.route('/watch-ad', methods=['POST'])
@token_required
def watch_ad(current_user):
    """مشاهدة إعلان وكسب نقاط"""
    try:
        # التحقق من إمكانية مشاهدة إعلان
        cooldown_seconds = current_app.config.get('AD_COOLDOWN_SECONDS', 60)
        
        if current_user.last_ad_watch:
            time_since_last_ad = datetime.utcnow() - current_user.last_ad_watch
            if time_since_last_ad.total_seconds() < cooldown_seconds:
                remaining = cooldown_seconds - int(time_since_last_ad.total_seconds())
                return jsonify({
                    'error': f'يجب الانتظار {remaining} ثانية قبل مشاهدة إعلان آخر'
                }), 429
        
        # نقاط الإعلان
        ad_points = current_app.config.get('AD_POINTS_PER_VIEW', 3)
        
        # إضافة النقاط للمستخدم
        transaction = current_user.add_points(ad_points, 'مشاهدة إعلان')
        
        # تحديث وقت آخر مشاهدة إعلان
        current_user.last_ad_watch = datetime.utcnow()
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='ad_watched',
            description=f'مشاهدة إعلان وكسب {ad_points} نقاط',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'pointsEarned': ad_points,
            'newBalance': current_user.points,
            'message': f'تم إضافة {ad_points} نقاط إلى رصيدك!'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error watching ad: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء مشاهدة الإعلان'}), 500

@points_bp.route('/add-bonus', methods=['POST'])
@token_required
def add_bonus_points(current_user):
    """إضافة نقاط مكافأة (للاستخدام مع بوت Discord)"""
    try:
        data = request.get_json()
        
        # التحقق من وجود توكن البوت
        bot_token = request.headers.get('Bot-Token')
        if bot_token != current_app.config.get('BOT_API_TOKEN'):
            return jsonify({'error': 'Unauthorized bot access'}), 401
        
        points_to_add = data.get('points', 0)
        reason = data.get('reason', 'مكافأة من البوت')
        
        if points_to_add <= 0:
            return jsonify({'error': 'يجب أن تكون النقاط أكبر من صفر'}), 400
        
        if points_to_add > 100:  # حد أقصى للمكافآت
            return jsonify({'error': 'الحد الأقصى للمكافأة 100 نقطة'}), 400
        
        # إضافة النقاط
        transaction = current_user.add_points(points_to_add, reason)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='bonus_points',
            description=f'{reason} (+{points_to_add} نقاط)',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'pointsAdded': points_to_add,
            'newBalance': current_user.points,
            'message': f'تم إضافة {points_to_add} نقاط كمكافأة!'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error adding bonus points: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إضافة المكافأة'}), 500

@points_bp.route('/add-from-bot', methods=['POST'])
def add_points_from_bot():
    """إضافة نقاط من بوت ديسكورد"""
    try:
        data = request.get_json()
        
        # التحقق من وجود المفاتيح المطلوبة
        required_fields = ['discord_id', 'points', 'bot_token']
        if not all(field in data for field in required_fields):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # التحقق من صحة توكن البوت
        expected_bot_token = current_app.config.get('BOT_API_TOKEN')
        if data['bot_token'] != expected_bot_token:
            return jsonify({'error': 'Invalid bot token'}), 401
        
        # البحث عن المستخدم
        user = User.query.filter_by(discord_id=data['discord_id']).first()
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # إضافة النقاط
        points_to_add = int(data['points'])
        reason = data.get('reason', 'نقاط من بوت ديسكورد')
        
        if points_to_add <= 0:
            return jsonify({'error': 'Points must be positive'}), 400
        
        if points_to_add > 100:  # حد أقصى للمكافآت
            return jsonify({'error': 'Maximum bonus is 100 points'}), 400
        
        transaction = user.add_points(points_to_add, reason)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=user.id,
            action='points_from_bot',
            description=f'تم إضافة {points_to_add} نقاط من بوت ديسكورد: {reason}',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        
        db.session.commit()
        
        return jsonify({
            'message': f'تم إضافة {points_to_add} نقاط بنجاح',
            'points_added': points_to_add,
            'total_points': user.points,
            'user': {
                'discord_id': user.discord_id,
                'username': user.username
            }
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error adding points from bot: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إضافة النقاط'}), 500

@points_bp.route('/leaderboard')
def get_leaderboard():
    """الحصول على قائمة أفضل المستخدمين بالنقاط"""
    try:
        limit = request.args.get('limit', 10, type=int)
        limit = min(limit, 50)  # حد أقصى 50 مستخدم
        
        # أفضل المستخدمين
        top_users = User.query.filter(
            User.is_banned == False
        ).order_by(User.points.desc()).limit(limit).all()
        
        leaderboard = []
        for i, user in enumerate(top_users, 1):
            leaderboard.append({
                'rank': i,
                'username': user.username,
                'points': user.points,
                'avatar': f"https://cdn.discordapp.com/avatars/{user.discord_id}/{user.avatar}.png" if user.avatar else None
            })
        
        return jsonify(leaderboard)
        
    except Exception as e:
        current_app.logger.error(f"Error fetching leaderboard: {str(e)}")
        return jsonify({'error': 'Failed to fetch leaderboard'}), 500

@points_bp.route('/stats')
@token_required
def get_user_stats(current_user):
    """إحصائيات المستخدم"""
    try:
        # إجمالي النقاط المكتسبة
        total_earned = db.session.query(
            db.func.sum(PointTransaction.amount)
        ).filter(
            PointTransaction.user_id == current_user.id,
            PointTransaction.transaction_type == 'earned'
        ).scalar() or 0
        
        # إجمالي النقاط المنفقة
        total_spent = db.session.query(
            db.func.sum(PointTransaction.amount)
        ).filter(
            PointTransaction.user_id == current_user.id,
            PointTransaction.transaction_type == 'spent'
        ).scalar() or 0
        
        # عدد الإعلانات المشاهدة
        ads_watched = PointTransaction.query.filter(
            PointTransaction.user_id == current_user.id,
            PointTransaction.reason.like('%إعلان%')
        ).count()
        
        # آخر نشاط
        last_transaction = PointTransaction.query.filter_by(
            user_id=current_user.id
        ).order_by(PointTransaction.created_at.desc()).first()
        
        # النقاط المكتسبة اليوم
        today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        today_earned = db.session.query(
            db.func.sum(PointTransaction.amount)
        ).filter(
            PointTransaction.user_id == current_user.id,
            PointTransaction.transaction_type == 'earned',
            PointTransaction.created_at >= today_start
        ).scalar() or 0
        
        return jsonify({
            'currentBalance': current_user.points,
            'totalEarned': total_earned,
            'totalSpent': abs(total_spent),
            'adsWatched': ads_watched,
            'todayEarned': today_earned,
            'lastActivity': last_transaction.created_at.isoformat() if last_transaction else None,
            'memberSince': current_user.created_at.isoformat()
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching user stats: {str(e)}")
        return jsonify({'error': 'Failed to fetch user stats'}), 500

