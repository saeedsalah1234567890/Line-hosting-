from flask import Blueprint, request, jsonify, current_app
from datetime import datetime, timedelta
from src.models.user import User, Subscription, Hosting, PointTransaction, ActivityLog, db
from src.routes.auth import token_required, admin_required
from sqlalchemy import func, desc
import docker

admin_bp = Blueprint('admin', __name__)

# إعداد Docker client
try:
    docker_client = docker.from_env()
except Exception as e:
    docker_client = None

@admin_bp.route('/stats')
@token_required
@admin_required
def get_admin_stats(current_user):
    """الحصول على إحصائيات عامة للمنصة"""
    try:
        # إحصائيات المستخدمين
        total_users = User.query.count()
        active_users = User.query.filter_by(is_banned=False).count()
        banned_users = User.query.filter_by(is_banned=True).count()
        
        # إحصائيات الاشتراكات
        active_subscriptions = Subscription.query.filter_by(is_active=True).count()
        total_subscriptions = Subscription.query.count()
        
        # إحصائيات البوتات
        total_bots = Hosting.query.count()
        running_bots = Hosting.query.filter_by(status='running').count()
        
        # إحصائيات النقاط
        total_points_earned = db.session.query(func.sum(PointTransaction.amount)).filter_by(transaction_type='earned').scalar() or 0
        total_points_spent = db.session.query(func.sum(PointTransaction.amount)).filter_by(transaction_type='spent').scalar() or 0
        
        # إحصائيات الإيرادات (بالنقاط)
        weekly_revenue = db.session.query(func.sum(PointTransaction.amount)).filter(
            PointTransaction.transaction_type == 'spent',
            PointTransaction.reason.like('%اشتراك%'),
            PointTransaction.created_at >= datetime.utcnow() - timedelta(days=7)
        ).scalar() or 0
        
        monthly_revenue = db.session.query(func.sum(PointTransaction.amount)).filter(
            PointTransaction.transaction_type == 'spent',
            PointTransaction.reason.like('%اشتراك%'),
            PointTransaction.created_at >= datetime.utcnow() - timedelta(days=30)
        ).scalar() or 0
        
        # نمو المستخدمين (آخر 30 يوم)
        new_users_last_month = User.query.filter(
            User.created_at >= datetime.utcnow() - timedelta(days=30)
        ).count()
        
        return jsonify({
            'users': {
                'total': total_users,
                'active': active_users,
                'banned': banned_users,
                'new_last_month': new_users_last_month
            },
            'subscriptions': {
                'active': active_subscriptions,
                'total': total_subscriptions
            },
            'bots': {
                'total': total_bots,
                'running': running_bots,
                'stopped': total_bots - running_bots
            },
            'points': {
                'total_earned': total_points_earned,
                'total_spent': total_points_spent,
                'weekly_revenue': weekly_revenue,
                'monthly_revenue': monthly_revenue
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching admin stats: {str(e)}")
        return jsonify({'error': 'Failed to fetch admin stats'}), 500

@admin_bp.route('/users')
@token_required
@admin_required
def get_all_users(current_user):
    """الحصول على جميع المستخدمين"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        search = request.args.get('search', '', type=str)
        
        query = User.query
        
        if search:
            query = query.filter(
                User.username.contains(search) | 
                User.discord_id.contains(search)
            )
        
        users = query.order_by(desc(User.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        users_data = []
        for user in users.items:
            user_data = user.to_dict()
            
            # إضافة معلومات إضافية
            user_data['active_subscription'] = user.has_active_subscription()
            user_data['total_bots'] = Hosting.query.filter_by(user_id=user.id).count()
            user_data['total_spent'] = db.session.query(func.sum(PointTransaction.amount)).filter_by(
                user_id=user.id, transaction_type='spent'
            ).scalar() or 0
            
            users_data.append(user_data)
        
        return jsonify({
            'users': users_data,
            'pagination': {
                'page': users.page,
                'pages': users.pages,
                'per_page': users.per_page,
                'total': users.total,
                'has_next': users.has_next,
                'has_prev': users.has_prev
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching users: {str(e)}")
        return jsonify({'error': 'Failed to fetch users'}), 500

@admin_bp.route('/users/<int:user_id>/ban', methods=['POST'])
@token_required
@admin_required
def ban_user(current_user, user_id):
    """حظر مستخدم"""
    try:
        user = User.query.get_or_404(user_id)
        
        if user.is_admin:
            return jsonify({'error': 'لا يمكن حظر مشرف'}), 400
        
        user.is_banned = True
        
        # إيقاف جميع بوتات المستخدم
        hostings = Hosting.query.filter_by(user_id=user_id).all()
        for hosting in hostings:
            if hosting.container_id and docker_client:
                try:
                    container = docker_client.containers.get(hosting.container_id)
                    container.stop(timeout=10)
                    hosting.status = 'stopped'
                except:
                    pass
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='user_banned',
            description=f'تم حظر المستخدم {user.username} (ID: {user.id})',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم حظر المستخدم {user.username} بنجاح'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error banning user: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء حظر المستخدم'}), 500

@admin_bp.route('/users/<int:user_id>/unban', methods=['POST'])
@token_required
@admin_required
def unban_user(current_user, user_id):
    """إلغاء حظر مستخدم"""
    try:
        user = User.query.get_or_404(user_id)
        
        user.is_banned = False
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='user_unbanned',
            description=f'تم إلغاء حظر المستخدم {user.username} (ID: {user.id})',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم إلغاء حظر المستخدم {user.username} بنجاح'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error unbanning user: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إلغاء حظر المستخدم'}), 500

@admin_bp.route('/users/<int:user_id>/points', methods=['POST'])
@token_required
@admin_required
def manage_user_points(current_user, user_id):
    """إدارة نقاط المستخدم"""
    try:
        user = User.query.get_or_404(user_id)
        data = request.get_json()
        
        action = data.get('action')  # add, subtract, set
        amount = data.get('amount', 0)
        reason = data.get('reason', 'تعديل من المشرف')
        
        if action not in ['add', 'subtract', 'set']:
            return jsonify({'error': 'نوع العملية غير صحيح'}), 400
        
        if amount < 0:
            return jsonify({'error': 'المبلغ يجب أن يكون موجباً'}), 400
        
        old_balance = user.points
        
        if action == 'add':
            user.points += amount
            transaction_type = 'earned'
            transaction_amount = amount
        elif action == 'subtract':
            if user.points < amount:
                return jsonify({'error': 'رصيد المستخدم غير كافي'}), 400
            user.points -= amount
            transaction_type = 'spent'
            transaction_amount = amount
        else:  # set
            transaction_amount = abs(amount - old_balance)
            transaction_type = 'earned' if amount > old_balance else 'spent'
            user.points = amount
        
        # تسجيل معاملة النقاط
        transaction = PointTransaction(
            user_id=user.id,
            transaction_type=transaction_type,
            amount=transaction_amount,
            reason=f'{reason} (بواسطة المشرف {current_user.username})',
            balance_after=user.points
        )
        db.session.add(transaction)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='points_modified',
            description=f'تم تعديل نقاط المستخدم {user.username} من {old_balance} إلى {user.points}',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم تعديل نقاط المستخدم {user.username} بنجاح',
            'old_balance': old_balance,
            'new_balance': user.points
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error managing user points: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء تعديل النقاط'}), 500

@admin_bp.route('/bots')
@token_required
@admin_required
def get_all_bots(current_user):
    """الحصول على جميع البوتات"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        bots = Hosting.query.join(User).order_by(desc(Hosting.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        bots_data = []
        for bot in bots.items:
            bot_data = bot.to_dict()
            bot_data['user'] = {
                'id': bot.user.id,
                'username': bot.user.username,
                'discord_id': bot.user.discord_id
            }
            
            # إضافة معلومات الحاوية
            if bot.container_id and docker_client:
                try:
                    container = docker_client.containers.get(bot.container_id)
                    bot_data['container_status'] = container.status
                    bot_data['container_health'] = container.attrs.get('State', {}).get('Health', {}).get('Status', 'unknown')
                except:
                    bot_data['container_status'] = 'not_found'
                    bot_data['container_health'] = 'unknown'
            
            bots_data.append(bot_data)
        
        return jsonify({
            'bots': bots_data,
            'pagination': {
                'page': bots.page,
                'pages': bots.pages,
                'per_page': bots.per_page,
                'total': bots.total,
                'has_next': bots.has_next,
                'has_prev': bots.has_prev
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching bots: {str(e)}")
        return jsonify({'error': 'Failed to fetch bots'}), 500

@admin_bp.route('/bots/<int:bot_id>/stop', methods=['POST'])
@token_required
@admin_required
def admin_stop_bot(current_user, bot_id):
    """إيقاف بوت (مشرف)"""
    try:
        hosting = Hosting.query.get_or_404(bot_id)
        
        if not hosting.container_id:
            return jsonify({'error': 'البوت غير مشغل'}), 400
        
        if not docker_client:
            return jsonify({'error': 'خدمة Docker غير متاحة'}), 503
        
        try:
            container = docker_client.containers.get(hosting.container_id)
            container.stop(timeout=10)
            
            hosting.status = 'stopped'
            hosting.last_stopped = datetime.utcnow()
            
            # تسجيل النشاط
            log = ActivityLog(
                user_id=current_user.id,
                action='admin_bot_stopped',
                description=f'تم إيقاف البوت {hosting.bot_name} (المالك: {hosting.user.username}) بواسطة المشرف',
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            db.session.add(log)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': f'تم إيقاف البوت {hosting.bot_name} بنجاح'
            })
            
        except docker.errors.NotFound:
            hosting.status = 'stopped'
            hosting.container_id = None
            db.session.commit()
            return jsonify({'error': 'الحاوية غير موجودة'}), 404
            
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error stopping bot: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إيقاف البوت'}), 500

@admin_bp.route('/bots/<int:bot_id>/delete', methods=['DELETE'])
@token_required
@admin_required
def admin_delete_bot(current_user, bot_id):
    """حذف بوت (مشرف)"""
    try:
        hosting = Hosting.query.get_or_404(bot_id)
        
        # إيقاف وحذف الحاوية إذا كانت موجودة
        if hosting.container_id and docker_client:
            try:
                container = docker_client.containers.get(hosting.container_id)
                container.stop(timeout=10)
                container.remove()
            except:
                pass
        
        bot_name = hosting.bot_name
        user_name = hosting.user.username
        
        # حذف سجل الاستضافة
        db.session.delete(hosting)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='admin_bot_deleted',
            description=f'تم حذف البوت {bot_name} (المالك: {user_name}) بواسطة المشرف',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم حذف البوت {bot_name} بنجاح'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting bot: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء حذف البوت'}), 500

@admin_bp.route('/subscriptions')
@token_required
@admin_required
def get_all_subscriptions(current_user):
    """الحصول على جميع الاشتراكات"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        subscriptions = Subscription.query.join(User).order_by(desc(Subscription.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        subscriptions_data = []
        for sub in subscriptions.items:
            sub_data = sub.to_dict()
            sub_data['user'] = {
                'id': sub.user.id,
                'username': sub.user.username,
                'discord_id': sub.user.discord_id
            }
            sub_data['days_remaining'] = sub.days_remaining()
            sub_data['is_expired'] = sub.is_expired()
            
            subscriptions_data.append(sub_data)
        
        return jsonify({
            'subscriptions': subscriptions_data,
            'pagination': {
                'page': subscriptions.page,
                'pages': subscriptions.pages,
                'per_page': subscriptions.per_page,
                'total': subscriptions.total,
                'has_next': subscriptions.has_next,
                'has_prev': subscriptions.has_prev
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching subscriptions: {str(e)}")
        return jsonify({'error': 'Failed to fetch subscriptions'}), 500

@admin_bp.route('/activity-logs')
@token_required
@admin_required
def get_activity_logs(current_user):
    """الحصول على سجل الأنشطة"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        logs = ActivityLog.query.order_by(desc(ActivityLog.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        logs_data = []
        for log in logs.items:
            log_data = log.to_dict()
            if log.user:
                log_data['user'] = {
                    'id': log.user.id,
                    'username': log.user.username
                }
            else:
                log_data['user'] = None
            
            logs_data.append(log_data)
        
        return jsonify({
            'logs': logs_data,
            'pagination': {
                'page': logs.page,
                'pages': logs.pages,
                'per_page': logs.per_page,
                'total': logs.total,
                'has_next': logs.has_next,
                'has_prev': logs.has_prev
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching activity logs: {str(e)}")
        return jsonify({'error': 'Failed to fetch activity logs'}), 500

@admin_bp.route('/system-info')
@token_required
@admin_required
def get_system_info(current_user):
    """الحصول على معلومات النظام"""
    try:
        system_info = {
            'docker_available': docker_client is not None,
            'database_connected': True,  # إذا وصلنا هنا فقاعدة البيانات متصلة
            'total_containers': 0,
            'running_containers': 0
        }
        
        if docker_client:
            try:
                containers = docker_client.containers.list(all=True, filters={'name': 'bothost_'})
                system_info['total_containers'] = len(containers)
                system_info['running_containers'] = len([c for c in containers if c.status == 'running'])
            except:
                system_info['docker_available'] = False
        
        return jsonify(system_info)
        
    except Exception as e:
        current_app.logger.error(f"Error fetching system info: {str(e)}")
        return jsonify({'error': 'Failed to fetch system info'}), 500

