#!/usr/bin/env python3
"""
Script لإنشاء مستخدم مشرف يدوياً
يمكن استخدامه في حالة الحاجة لإضافة مشرف جديد بدون تسجيل دخول Discord
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# تعيين البيئة للتطوير إذا لم تكن محددة
if not os.environ.get('FLASK_ENV'):
    os.environ['FLASK_ENV'] = 'development'

from src.models.user import User, ActivityLog, db
from src.main import create_app

def create_admin_user(discord_id, username, email=None):
    """إنشاء مستخدم مشرف جديد"""
    app = create_app()
    with app.app_context():
        # التحقق من وجود المستخدم
        existing_user = User.query.filter_by(discord_id=discord_id).first()
        
        if existing_user:
            if existing_user.is_admin:
                print(f"المستخدم {username} ({discord_id}) مشرف بالفعل")
                return existing_user
            else:
                # ترقية المستخدم الموجود إلى مشرف
                existing_user.is_admin = True
                
                # تسجيل النشاط
                log = ActivityLog(
                    user_id=existing_user.id,
                    action='manual_admin_promotion',
                    description='تم ترقية المستخدم إلى مشرف يدوياً',
                    ip_address='127.0.0.1',
                    user_agent='Admin Script'
                )
                db.session.add(log)
                db.session.commit()
                
                print(f"تم ترقية المستخدم {username} ({discord_id}) إلى مشرف")
                return existing_user
        else:
            # إنشاء مستخدم جديد مع صلاحيات المشرف
            new_user = User(
                discord_id=discord_id,
                username=username,
                email=email,
                points=1000,  # نقاط إضافية للمشرف
                is_admin=True
            )
            
            db.session.add(new_user)
            db.session.flush()  # للحصول على ID
            
            # تسجيل النشاط
            log = ActivityLog(
                user_id=new_user.id,
                action='manual_admin_creation',
                description='تم إنشاء مستخدم مشرف يدوياً',
                ip_address='127.0.0.1',
                user_agent='Admin Script'
            )
            db.session.add(log)
            db.session.commit()
            
            print(f"تم إنشاء المستخدم المشرف {username} ({discord_id}) بنجاح")
            return new_user

def list_admins():
    """عرض قائمة بجميع المشرفين"""
    app = create_app()
    with app.app_context():
        admins = User.query.filter_by(is_admin=True).all()
        
        if not admins:
            print("لا يوجد مشرفين في النظام")
            return
        
        print("قائمة المشرفين:")
        print("-" * 50)
        for admin in admins:
            print(f"ID: {admin.id}")
            print(f"Discord ID: {admin.discord_id}")
            print(f"Username: {admin.username}")
            print(f"Email: {admin.email or 'غير محدد'}")
            print(f"Points: {admin.points}")
            print(f"Created: {admin.created_at}")
            print("-" * 50)

def remove_admin(discord_id):
    """إزالة صلاحيات المشرف من مستخدم"""
    app = create_app()
    with app.app_context():
        user = User.query.filter_by(discord_id=discord_id).first()
        
        if not user:
            print(f"لم يتم العثور على مستخدم بـ Discord ID: {discord_id}")
            return
        
        if not user.is_admin:
            print(f"المستخدم {user.username} ليس مشرف")
            return
        
        user.is_admin = False
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=user.id,
            action='manual_admin_removal',
            description='تم إزالة صلاحيات المشرف يدوياً',
            ip_address='127.0.0.1',
            user_agent='Admin Script'
        )
        db.session.add(log)
        db.session.commit()
        
        print(f"تم إزالة صلاحيات المشرف من {user.username} ({discord_id})")

def show_config():
    """عرض إعدادات المشرفين الحالية"""
    app = create_app()
    with app.app_context():
        admin_ids = app.config.get('ADMIN_DISCORD_IDS', [])
        print("إعدادات المشرفين التلقائيين:")
        print("-" * 40)
        if admin_ids:
            for i, admin_id in enumerate(admin_ids, 1):
                print(f"{i}. Discord ID: {admin_id}")
        else:
            print("لا توجد إعدادات مشرفين تلقائيين")
        print("-" * 40)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("الاستخدام:")
        print("  python create_admin.py create <discord_id> <username> [email]")
        print("  python create_admin.py list")
        print("  python create_admin.py remove <discord_id>")
        print("  python create_admin.py config")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "create":
        if len(sys.argv) < 4:
            print("خطأ: يجب تحديد Discord ID و Username")
            sys.exit(1)
        
        discord_id = sys.argv[2]
        username = sys.argv[3]
        email = sys.argv[4] if len(sys.argv) > 4 else None
        
        create_admin_user(discord_id, username, email)
    
    elif command == "list":
        list_admins()
    
    elif command == "remove":
        if len(sys.argv) < 3:
            print("خطأ: يجب تحديد Discord ID")
            sys.exit(1)
        
        discord_id = sys.argv[2]
        remove_admin(discord_id)
    
    elif command == "config":
        show_config()
    
    else:
        print(f"أمر غير معروف: {command}")
        sys.exit(1)

