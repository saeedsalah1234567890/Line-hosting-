import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask
from flask_cors import CORS
from src.config import get_config
from src.models.user import db
from src.routes.auth import auth_bp
from src.routes.points import points_bp
from src.routes.subscription import subscription_bp, start_subscription_monitor
from src.routes.hosting import hosting_bp, start_container_monitor
from src.routes.admin import admin_bp

def create_app():
    """إنشاء تطبيق Flask"""
    app = Flask(__name__)
    
    # تحميل الإعدادات
    config_class = get_config()
    app.config.from_object(config_class)
    
    # تهيئة قاعدة البيانات
    db.init_app(app)
    
    # تهيئة CORS
    CORS(app, origins=app.config.get('CORS_ORIGINS', ['*']))
    
    # تسجيل المسارات
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(points_bp, url_prefix='/api/points')
    app.register_blueprint(subscription_bp, url_prefix='/api/subscription')
    app.register_blueprint(hosting_bp, url_prefix='/api/hosting')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    
    # إنشاء الجداول
    with app.app_context():
        db.create_all()
        print("✅ تم إنشاء جداول قاعدة البيانات بنجاح")
        
        # بدء مراقب الاشتراكات
        start_subscription_monitor()
        print("✅ تم بدء مراقب الاشتراكات")
        
        # بدء مراقب الحاويات
        start_container_monitor()
        print("✅ تم بدء مراقب الحاويات")
    
    @app.route('/')
    def index():
        return {
            'message': 'مرحباً بك في منصة استضافة البوتات',
            'version': '1.0.0',
            'status': 'running'
        }
    
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'timestamp': db.func.now()}
    
    return app

if __name__ == '__main__':
    print("🚀 بدء تشغيل خادم استضافة البوتات...")
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)r
        if static_folder_path is None:
                return "Static folder not configured", 404

        if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
            return send_from_directory(static_folder_path, path)
        else:
            index_path = os.path.join(static_folder_path, 'index.html')
            if os.path.exists(index_path):
                return send_from_directory(static_folder_path, 'index.html')
            else:
                return "index.html not found", 404
    
    # مسار للتحقق من صحة التطبيق
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'service': 'bot-hosting-platform'}
    
    return app

# إنشاء التطبيق
app = create_app()

if __name__ == '__main__':
    try:
        # التحقق من صحة الإعدادات في وضع التطوير
        if os.environ.get('FLASK_ENV') == 'development':
            print("🔧 وضع التطوير - التحقق من الإعدادات...")
            try:
                validate_config()
                print("✅ جميع الإعدادات المطلوبة موجودة")
            except ValueError as e:
                print(f"⚠️  تحذير: {e}")
                print("💡 يمكنك إنشاء ملف .env للتطوير المحلي")
        
        print("🚀 بدء تشغيل خادم استضافة البوتات...")
        app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=app.config['DEBUG'])
        
    except Exception as e:
        print(f"❌ خطأ في بدء التشغيل: {e}")
        sys.exit(1)
