from flask import Blueprint, request, jsonify, current_app
from datetime import datetime, timedelta
from src.models.user import User, Subscription, PointTransaction, ActivityLog, db
from src.routes.auth import token_required
import threading
import time

subscription_bp = Blueprint('subscription', __name__)

@subscription_bp.route('/plans')
def get_subscription_plans():
    """الحصول على خطط الاشتراك المتاحة"""
    try:
        plans = [
            {
                'id': 'weekly',
                'name': 'اشتراك أسبوعي',
                'duration_days': 7,
                'points_cost': current_app.config.get('WEEKLY_SUBSCRIPTION_POINTS', 15),
                'features': [
                    'استضافة بوت واحد',
                    'تشغيل 24/7',
                    'دعم جميع اللغات',
                    'مساحة تخزين 100MB',
                    'ذاكرة 512MB'
                ],
                'popular': False
            },
            {
                'id': 'monthly',
                'name': 'اشتراك شهري',
                'duration_days': 30,
                'points_cost': current_app.config.get('MONTHLY_SUBSCRIPTION_POINTS', 60),
                'features': [
                    'استضافة بوت واحد',
                    'تشغيل 24/7',
                    'دعم جميع اللغات',
                    'مساحة تخزين 500MB',
                    'ذاكرة 1GB',
                    'أولوية في الدعم'
                ],
                'popular': True,
                'savings': 'توفير 4 نقاط!'
            }
        ]
        
        return jsonify({
            'plans': plans,
            'currency': 'نقطة'
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching subscription plans: {str(e)}")
        return jsonify({'error': 'Failed to fetch subscription plans'}), 500

@subscription_bp.route('/status')
@token_required
def get_subscription_status(current_user):
    """الحصول على حالة الاشتراك الحالي"""
    try:
        # البحث عن الاشتراك النشط
        active_subscription = Subscription.query.filter_by(
            user_id=current_user.id,
            is_active=True
        ).first()
        
        if not active_subscription:
            return jsonify({
                'hasActiveSubscription': False,
                'message': 'لا يوجد اشتراك نشط'
            })
        
        # حساب الوقت المتبقي
        time_remaining = active_subscription.expires_at - datetime.utcnow()
        days_remaining = max(0, time_remaining.days)
        hours_remaining = max(0, time_remaining.seconds // 3600)
        
        return jsonify({
            'hasActiveSubscription': True,
            'subscription': {
                'id': active_subscription.id,
                'plan_type': active_subscription.plan_type,
                'plan_name': 'اشتراك أسبوعي' if active_subscription.plan_type == 'weekly' else 'اشتراك شهري',
                'created_at': active_subscription.created_at.isoformat(),
                'expires_at': active_subscription.expires_at.isoformat(),
                'auto_renew': active_subscription.auto_renew,
                'days_remaining': days_remaining,
                'hours_remaining': hours_remaining,
                'is_expiring_soon': days_remaining <= 2
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Error fetching subscription status: {str(e)}")
        return jsonify({'error': 'Failed to fetch subscription status'}), 500

@subscription_bp.route('/subscribe', methods=['POST'])
@token_required
def create_subscription(current_user):
    """إنشاء اشتراك جديد"""
    try:
        data = request.get_json()
        plan_type = data.get('plan_type')
        auto_renew = data.get('auto_renew', True)
        
        if plan_type not in ['weekly', 'monthly']:
            return jsonify({'error': 'نوع الاشتراك غير صحيح'}), 400
        
        # التحقق من وجود اشتراك نشط
        existing_subscription = Subscription.query.filter_by(
            user_id=current_user.id,
            is_active=True
        ).first()
        
        if existing_subscription:
            return jsonify({'error': 'لديك اشتراك نشط بالفعل'}), 400
        
        # حساب التكلفة والمدة
        if plan_type == 'weekly':
            cost = current_app.config.get('WEEKLY_SUBSCRIPTION_POINTS', 15)
            duration_days = 7
        else:  # monthly
            cost = current_app.config.get('MONTHLY_SUBSCRIPTION_POINTS', 60)
            duration_days = 30
        
        # التحقق من كفاية النقاط
        if current_user.points < cost:
            return jsonify({
                'error': f'نقاطك غير كافية. تحتاج {cost} نقطة ولديك {current_user.points} نقطة'
            }), 400
        
        # خصم النقاط
        current_user.points -= cost
        
        # إنشاء الاشتراك
        expires_at = datetime.utcnow() + timedelta(days=duration_days)
        subscription = Subscription(
            user_id=current_user.id,
            plan_type=plan_type,
            points_cost=cost,
            expires_at=expires_at,
            auto_renew=auto_renew,
            is_active=True
        )
        db.session.add(subscription)
        
        # تسجيل معاملة النقاط
        transaction = PointTransaction(
            user_id=current_user.id,
            transaction_type='spent',
            amount=cost,
            reason=f'شراء اشتراك {plan_type}',
            balance_after=current_user.points
        )
        db.session.add(transaction)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='subscription_created',
            description=f'تم إنشاء اشتراك {plan_type} لمدة {duration_days} أيام',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم إنشاء الاشتراك بنجاح! ينتهي في {expires_at.strftime("%Y-%m-%d")}',
            'subscription': {
                'id': subscription.id,
                'plan_type': plan_type,
                'expires_at': expires_at.isoformat(),
                'auto_renew': auto_renew
            },
            'remaining_points': current_user.points
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error creating subscription: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إنشاء الاشتراك'}), 500

@subscription_bp.route('/renew', methods=['POST'])
@token_required
def renew_subscription(current_user):
    """تجديد الاشتراك يدوياً"""
    try:
        # البحث عن الاشتراك النشط
        subscription = Subscription.query.filter_by(
            user_id=current_user.id,
            is_active=True
        ).first()
        
        if not subscription:
            return jsonify({'error': 'لا يوجد اشتراك نشط للتجديد'}), 400
        
        # حساب التكلفة
        if subscription.plan_type == 'weekly':
            cost = current_app.config.get('WEEKLY_SUBSCRIPTION_POINTS', 15)
            duration_days = 7
        else:  # monthly
            cost = current_app.config.get('MONTHLY_SUBSCRIPTION_POINTS', 60)
            duration_days = 30
        
        # التحقق من كفاية النقاط
        if current_user.points < cost:
            return jsonify({
                'error': f'نقاطك غير كافية للتجديد. تحتاج {cost} نقطة ولديك {current_user.points} نقطة'
            }), 400
        
        # خصم النقاط
        current_user.points -= cost
        
        # تمديد الاشتراك
        subscription.expires_at = subscription.expires_at + timedelta(days=duration_days)
        
        # تسجيل معاملة النقاط
        transaction = PointTransaction(
            user_id=current_user.id,
            transaction_type='spent',
            amount=cost,
            reason=f'تجديد اشتراك {subscription.plan_type}',
            balance_after=current_user.points
        )
        db.session.add(transaction)
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='subscription_renewed',
            description=f'تم تجديد الاشتراك {subscription.plan_type} لمدة {duration_days} أيام إضافية',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'تم تجديد الاشتراك بنجاح! ينتهي في {subscription.expires_at.strftime("%Y-%m-%d")}',
            'new_expiry': subscription.expires_at.isoformat(),
            'remaining_points': current_user.points
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error renewing subscription: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء تجديد الاشتراك'}), 500

@subscription_bp.route('/toggle-auto-renew', methods=['POST'])
@token_required
def toggle_auto_renew(current_user):
    """تفعيل/إلغاء التجديد التلقائي"""
    try:
        subscription = Subscription.query.filter_by(
            user_id=current_user.id,
            is_active=True
        ).first()
        
        if not subscription:
            return jsonify({'error': 'لا يوجد اشتراك نشط'}), 400
        
        # تبديل حالة التجديد التلقائي
        subscription.auto_renew = not subscription.auto_renew
        
        # تسجيل النشاط
        action = 'auto_renew_enabled' if subscription.auto_renew else 'auto_renew_disabled'
        log = ActivityLog(
            user_id=current_user.id,
            action=action,
            description=f'تم {"تفعيل" if subscription.auto_renew else "إلغاء"} التجديد التلقائي',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'auto_renew': subscription.auto_renew,
            'message': f'تم {"تفعيل" if subscription.auto_renew else "إلغاء"} التجديد التلقائي'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error toggling auto-renew: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء تحديث إعدادات التجديد'}), 500

@subscription_bp.route('/cancel', methods=['POST'])
@token_required
def cancel_subscription(current_user):
    """إلغاء الاشتراك"""
    try:
        subscription = Subscription.query.filter_by(
            user_id=current_user.id,
            is_active=True
        ).first()
        
        if not subscription:
            return jsonify({'error': 'لا يوجد اشتراك نشط للإلغاء'}), 400
        
        # إلغاء الاشتراك
        subscription.is_active = False
        subscription.auto_renew = False
        subscription.cancelled_at = datetime.utcnow()
        
        # تسجيل النشاط
        log = ActivityLog(
            user_id=current_user.id,
            action='subscription_cancelled',
            description='تم إلغاء الاشتراك',
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        db.session.add(log)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'تم إلغاء الاشتراك بنجاح'
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error cancelling subscription: {str(e)}")
        return jsonify({'error': 'حدث خطأ أثناء إلغاء الاشتراك'}), 500

@subscription_bp.route('/history')
@token_required
def get_subscription_history(current_user):
    """الحصول على تاريخ الاشتراكات"""
    try:
        subscriptions = Subscription.query.filter_by(
            user_id=current_user.id
        ).order_by(Subscription.created_at.desc()).limit(20).all()
        
        history = []
        for sub in subscriptions:
            history.append({
                'id': sub.id,
                'plan_type': sub.plan_type,
                'plan_name': 'اشتراك أسبوعي' if sub.plan_type == 'weekly' else 'اشتراك شهري',
                'points_cost': sub.points_cost,
                'created_at': sub.created_at.isoformat(),
                'expires_at': sub.expires_at.isoformat(),
                'cancelled_at': sub.cancelled_at.isoformat() if sub.cancelled_at else None,
                'is_active': sub.is_active,
                'auto_renew': sub.auto_renew,
                'status': 'نشط' if sub.is_active else ('ملغي' if sub.cancelled_at else 'منتهي')
            })
        
        return jsonify(history)
        
    except Exception as e:
        current_app.logger.error(f"Error fetching subscription history: {str(e)}")
        return jsonify({'error': 'Failed to fetch subscription history'}), 500

def check_expired_subscriptions():
    """فحص الاشتراكات المنتهية وتجديدها تلقائياً"""
    try:
        with current_app.app_context():
            # البحث عن الاشتراكات المنتهية
            expired_subscriptions = Subscription.query.filter(
                Subscription.is_active == True,
                Subscription.expires_at <= datetime.utcnow()
            ).all()
            
            for subscription in expired_subscriptions:
                user = User.query.get(subscription.user_id)
                
                if subscription.auto_renew and user:
                    # حساب التكلفة
                    if subscription.plan_type == 'weekly':
                        cost = current_app.config.get('WEEKLY_SUBSCRIPTION_POINTS', 15)
                        duration_days = 7
                    else:  # monthly
                        cost = current_app.config.get('MONTHLY_SUBSCRIPTION_POINTS', 60)
                        duration_days = 30
                    
                    # التحقق من كفاية النقاط للتجديد التلقائي
                    if user.points >= cost:
                        # خصم النقاط
                        user.points -= cost
                        
                        # تمديد الاشتراك
                        subscription.expires_at = datetime.utcnow() + timedelta(days=duration_days)
                        
                        # تسجيل معاملة النقاط
                        transaction = PointTransaction(
                            user_id=user.id,
                            transaction_type='spent',
                            amount=cost,
                            reason=f'تجديد تلقائي لاشتراك {subscription.plan_type}',
                            balance_after=user.points
                        )
                        db.session.add(transaction)
                        
                        # تسجيل النشاط
                        log = ActivityLog(
                            user_id=user.id,
                            action='subscription_auto_renewed',
                            description=f'تم التجديد التلقائي للاشتراك {subscription.plan_type}',
                            ip_address='127.0.0.1',
                            user_agent='Auto Renewal System'
                        )
                        db.session.add(log)
                        
                        current_app.logger.info(f"Auto-renewed subscription {subscription.id} for user {user.username}")
                    else:
                        # إلغاء الاشتراك لعدم كفاية النقاط
                        subscription.is_active = False
                        subscription.auto_renew = False
                        
                        # تسجيل النشاط
                        log = ActivityLog(
                            user_id=user.id,
                            action='subscription_expired_insufficient_points',
                            description=f'انتهى الاشتراك {subscription.plan_type} لعدم كفاية النقاط للتجديد التلقائي',
                            ip_address='127.0.0.1',
                            user_agent='Auto Renewal System'
                        )
                        db.session.add(log)
                        
                        current_app.logger.warning(f"Subscription {subscription.id} expired - insufficient points for user {user.username}")
                else:
                    # إلغاء الاشتراك (التجديد التلقائي معطل أو المستخدم غير موجود)
                    subscription.is_active = False
                    
                    if user:
                        # تسجيل النشاط
                        log = ActivityLog(
                            user_id=user.id,
                            action='subscription_expired',
                            description=f'انتهى الاشتراك {subscription.plan_type}',
                            ip_address='127.0.0.1',
                            user_agent='Auto Renewal System'
                        )
                        db.session.add(log)
                    
                    current_app.logger.info(f"Subscription {subscription.id} expired naturally")
            
            db.session.commit()
            
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error checking expired subscriptions: {str(e)}")

def start_subscription_monitor():
    """بدء مراقب الاشتراكات"""
    def monitor():
        while True:
            try:
                check_expired_subscriptions()
                time.sleep(300)  # فحص كل 5 دقائق
            except Exception as e:
                current_app.logger.error(f"Subscription monitor error: {str(e)}")
                time.sleep(60)  # انتظار دقيقة في حالة الخطأ
    
    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()
    current_app.logger.info("Subscription monitor started")

