import { useState, useEffect } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { 
  Menu, 
  X, 
  Home, 
  LayoutDashboard,
  Coins, 
  CreditCard, 
  Server, 
  Shield, 
  LogOut,
  User
} from 'lucide-react'ct'

const Layout = ({ children }) => {
  const [user, setUser] = useState(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => {
    // التحقق من وجود توكن المستخدم
    const token = localStorage.getItem('token')
    if (token) {
      fetchUserInfo(token)
    }
  }, [])

  const fetchUserInfo = async (token) => {
    try {
      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      
      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
      } else {
        localStorage.removeItem('token')
      }
    } catch (error) {
      console.error('Error fetching user info:', error)
      localStorage.removeItem('token')
    }
  }

  const handleLogout = async () => {
    try {
      const token = localStorage.getItem('token')
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
      }
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      localStorage.removeItem('token')
      setUser(null)
      navigate('/')
    }
  }

  const navigation = [
    { name: 'الرئيسية', href: '/', icon: Home },
    { name: 'لوحة التحكم', href: '/dashboard', icon: LayoutDashboard },
    { name: 'النقاط', href: '/points', icon: Coins },
    { name: 'الاشتراكات', href: '/subscriptions', icon: CreditCard },
    { name: 'الاستضافة', href: '/hosting', icon: Server },
  ]

  const adminNavigation = [
    { name: 'لوحة المشرف', href: '/admin', icon: Shield },
  ]

  const isActive = (path) => {
    return location.pathname === path
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="md:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
              >
                {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
              <Link to="/" className="flex items-center space-x-3 rtl:space-x-reverse">
                <Server className="h-8 w-8 text-blue-600" />
                <span className="text-xl font-bold text-gray-900 dark:text-white">
                  استضافة البوتات
                </span>
              </Link>
            </div>

            {/* User Menu */}
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              {user ? (
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <Coins className="h-5 w-5 text-yellow-500" />
                    <span className="font-medium text-gray-900 dark:text-white">
                      {user.points} نقطة
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    {user.avatar && (
                      <img
                        src={`https://cdn.discordapp.com/avatars/${user.discord_id}/${user.avatar}.png`}
                        alt={user.username}
                        className="h-8 w-8 rounded-full"
                      />
                    )}
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {user.username}
                    </span>
                  </div>
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    size="sm"
                    className="flex items-center space-x-2 rtl:space-x-reverse"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>خروج</span>
                  </Button>
                </div>
              ) : (
                <Button asChild>
                  <a href="/api/auth/login">
                    تسجيل الدخول بـ Discord
                  </a>
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        {user && (
          <nav className={`
            ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
            md:translate-x-0 fixed md:static inset-y-0 right-0 z-50
            w-64 bg-white dark:bg-gray-800 shadow-lg border-l md:border-l-0 md:border-r
            transition-transform duration-300 ease-in-out
            pt-16 md:pt-0
          `}>
            <div className="p-4">
              <div className="space-y-1">
                {navigation.map((item) => {
                  const Icon = item.icon
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      onClick={() => setSidebarOpen(false)}
                      className={`
                        flex items-center space-x-3 rtl:space-x-reverse px-3 py-2 rounded-md text-sm font-medium
                        ${isActive(item.href)
                          ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200'
                          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white'
                        }
                      `}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{item.name}</span>
                    </Link>
                  )
                })}

                {user.is_admin && (
                  <div className="pt-4 mt-4 border-t border-gray-200 dark:border-gray-700">
                    {adminNavigation.map((item) => {
                      const Icon = item.icon
                      return (
                        <Link
                          key={item.name}
                          to={item.href}
                          onClick={() => setSidebarOpen(false)}
                          className={`
                            flex items-center space-x-3 rtl:space-x-reverse px-3 py-2 rounded-md text-sm font-medium
                            ${isActive(item.href)
                              ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-200'
                              : 'text-red-600 hover:bg-red-100 hover:text-red-900 dark:text-red-400 dark:hover:bg-red-900 dark:hover:text-red-200'
                            }
                          `}
                        >
                          <Icon className="h-5 w-5" />
                          <span>{item.name}</span>
                        </Link>
                      )
                    })}
                  </div>
                )}
              </div>
            </div>
          </nav>
        )}

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className={`flex-1 ${user ? 'md:mr-64' : ''} min-h-screen`}>
          <div className="p-4 md:p-8">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}

export default Layout

