import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Server, 
  Coins, 
  Clock, 
  Shield, 
  Code, 
  Zap,
  Users,
  Star,
  CheckCircle,
  ArrowLeft
} from 'lucide-react'

const Home = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeHostings: 0,
    totalPointsDistributed: 0
  })

  useEffect(() => {
    // يمكن إضافة API لجلب الإحصائيات العامة هنا
    setStats({
      totalUsers: 1250,
      activeHostings: 847,
      totalPointsDistributed: 125000
    })
  }, [])

  const features = [
    {
      icon: Server,
      title: 'استضافة مجانية',
      description: 'استضف بوتك مجاناً باستخدام نظام النقاط'
    },
    {
      icon: Code,
      title: 'دعم متعدد اللغات',
      description: 'Node.js, Python, Java, PHP, Bash'
    },
    {
      icon: Clock,
      title: 'تشغيل 24/7',
      description: 'بوتك يعمل على مدار الساعة'
    },
    {
      icon: Shield,
      title: 'آمن ومعزول',
      description: 'كل بوت في حاوية منفصلة وآمنة'
    },
    {
      icon: Zap,
      title: 'سهل الاستخدام',
      description: 'لوحة تحكم بسيطة وقوية'
    },
    {
      icon: Coins,
      title: 'نظام نقاط ذكي',
      description: 'اكسب نقاط من الإعلانات أو بوت Discord'
    }
  ]

  const plans = [
    {
      name: 'أسبوعي',
      price: '15 نقطة',
      duration: '7 أيام',
      features: [
        'استضافة بوت واحد',
        'دعم جميع اللغات',
        'لوحة تحكم كاملة',
        'تشغيل 24/7',
        'تغيير اللغة أثناء التشغيل'
      ]
    },
    {
      name: 'شهري',
      price: '60 نقطة',
      duration: '30 يوم',
      popular: true,
      features: [
        'استضافة بوت واحد',
        'دعم جميع اللغات',
        'لوحة تحكم كاملة',
        'تشغيل 24/7',
        'تغيير اللغة أثناء التشغيل',
        'توفير 4 نقاط مجانية'
      ]
    }
  ]

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="text-center py-12 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-800 dark:to-gray-900 rounded-2xl">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
            استضافة البوتات
            <span className="text-blue-600 dark:text-blue-400"> المجانية</span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            منصة استضافة البوتات الأولى في المنطقة بنظام النقاط. 
            ادعم جميع لغات البرمجة مع لوحة تحكم متكاملة وسهلة الاستخدام.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild className="text-lg px-8 py-3">
              <a href="/api/auth/login">
                ابدأ الآن مجاناً
                <ArrowLeft className="mr-2 h-5 w-5" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild className="text-lg px-8 py-3">
              <Link to="/points">
                تعرف على النقاط
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="text-center">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-blue-600">
              {stats.totalUsers.toLocaleString()}
            </CardTitle>
            <CardDescription>مستخدم مسجل</CardDescription>
          </CardHeader>
        </Card>
        <Card className="text-center">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-green-600">
              {stats.activeHostings.toLocaleString()}
            </CardTitle>
            <CardDescription>بوت نشط</CardDescription>
          </CardHeader>
        </Card>
        <Card className="text-center">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-yellow-600">
              {stats.totalPointsDistributed.toLocaleString()}
            </CardTitle>
            <CardDescription>نقطة موزعة</CardDescription>
          </CardHeader>
        </Card>
      </section>

      {/* Features Section */}
      <section>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            لماذا تختار منصتنا؟
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            نوفر لك كل ما تحتاجه لاستضافة بوتك بأفضل جودة وأقل تكلفة
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                      <Icon className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </section>

      {/* Pricing Section */}
      <section>
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            خطط الاشتراك
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            اختر الخطة التي تناسبك واستمتع بأفضل خدمة استضافة
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${plan.popular ? 'ring-2 ring-blue-500 shadow-lg' : ''}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    الأكثر شعبية
                  </span>
                </div>
              )}
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-blue-600">{plan.price}</span>
                  <span className="text-gray-600 dark:text-gray-400 mr-2">/ {plan.duration}</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3 rtl:space-x-reverse">
                      <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button className="w-full mt-6" size="lg" asChild>
                  <Link to="/subscriptions">
                    اشترك الآن
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 dark:bg-blue-800 rounded-2xl p-8 text-center text-white">
        <h2 className="text-3xl font-bold mb-4">
          جاهز لبدء استضافة بوتك؟
        </h2>
        <p className="text-xl mb-6 opacity-90">
          انضم إلى آلاف المطورين الذين يثقون بمنصتنا
        </p>
        <Button size="lg" variant="secondary" asChild className="text-lg px-8 py-3">
          <a href="/api/auth/login">
            ابدأ مجاناً الآن
            <ArrowLeft className="mr-2 h-5 w-5" />
          </a>
        </Button>
      </section>
    </div>
  )
}

export default Home

