import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Coins, 
  Play, 
  Clock, 
  TrendingUp, 
  Gift,
  History,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Loader2
} from 'lucide-react'

const Points = () => {
  const [user, setUser] = useState(null)
  const [pointsHistory, setPointsHistory] = useState([])
  const [adStatus, setAdStatus] = useState({
    canWatch: true,
    cooldownRemaining: 0,
    isWatching: false
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchUserData()
    fetchPointsHistory()
    checkAdStatus()
    
    // تحديث حالة الإعلانات كل ثانية
    const interval = setInterval(checkAdStatus, 1000)
    return () => clearInterval(interval)
  }, [])

  const fetchUserData = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
      }
    } catch (error) {
      console.error('Error fetching user data:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchPointsHistory = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/points/history', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const history = await response.json()
        setPointsHistory(history)
      }
    } catch (error) {
      console.error('Error fetching points history:', error)
    }
  }

  const checkAdStatus = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/points/ad-status', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const status = await response.json()
        setAdStatus(status)
      }
    } catch (error) {
      console.error('Error checking ad status:', error)
    }
  }

  const watchAd = async () => {
    if (!adStatus.canWatch || adStatus.isWatching) return

    setAdStatus(prev => ({ ...prev, isWatching: true }))

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/points/watch-ad', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      })

      if (response.ok) {
        const result = await response.json()
        
        // محاكاة مشاهدة الإعلان (30 ثانية)
        setTimeout(() => {
          setUser(prev => ({ ...prev, points: result.newBalance }))
          fetchPointsHistory()
          checkAdStatus()
          setAdStatus(prev => ({ ...prev, isWatching: false }))
        }, 30000)
      } else {
        setAdStatus(prev => ({ ...prev, isWatching: false }))
        const error = await response.json()
        alert(error.error || 'حدث خطأ أثناء مشاهدة الإعلان')
      }
    } catch (error) {
      console.error('Error watching ad:', error)
      setAdStatus(prev => ({ ...prev, isWatching: false }))
      alert('حدث خطأ في الاتصال')
    }
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const getActionIcon = (action) => {
    switch (action) {
      case 'ad_watched':
        return <Play className="h-4 w-4 text-green-500" />
      case 'subscription_purchase':
        return <TrendingUp className="h-4 w-4 text-red-500" />
      case 'bonus':
        return <Gift className="h-4 w-4 text-blue-500" />
      case 'account_created':
        return <CheckCircle className="h-4 w-4 text-purple-500" />
      default:
        return <Coins className="h-4 w-4 text-yellow-500" />
    }
  }

  const getActionText = (action) => {
    switch (action) {
      case 'ad_watched':
        return 'مشاهدة إعلان'
      case 'subscription_purchase':
        return 'شراء اشتراك'
      case 'bonus':
        return 'مكافأة'
      case 'account_created':
        return 'إنشاء حساب'
      default:
        return action
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          يجب تسجيل الدخول
        </h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          سجل دخولك لعرض نقاطك ومشاهدة الإعلانات
        </p>
        <Button asChild>
          <a href="/api/auth/login">تسجيل الدخول</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* رأس الصفحة */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          نقاطك
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          اكسب نقاط من مشاهدة الإعلانات واستخدمها للاشتراك في استضافة البوتات
        </p>
      </div>

      {/* رصيد النقاط */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
              <Coins className="h-6 w-6 text-yellow-500" />
              <span>رصيدك الحالي</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-yellow-600 mb-4">
              {user.points.toLocaleString()} نقطة
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>اشتراك أسبوعي</span>
                <span>15 نقطة</span>
              </div>
              <Progress 
                value={(user.points / 15) * 100} 
                className="h-2"
              />
              <div className="flex justify-between text-sm">
                <span>اشتراك شهري</span>
                <span>60 نقطة</span>
              </div>
              <Progress 
                value={(user.points / 60) * 100} 
                className="h-2"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
              <Play className="h-6 w-6 text-green-500" />
              <span>مشاهدة الإعلانات</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {adStatus.isWatching ? (
              <div className="text-center">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-500" />
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
                  جاري تشغيل الإعلان...
                </p>
                <Badge variant="secondary">30 ثانية متبقية</Badge>
              </div>
            ) : adStatus.canWatch ? (
              <div className="text-center">
                <Button 
                  onClick={watchAd}
                  className="w-full mb-4"
                  size="lg"
                >
                  <Play className="h-4 w-4 ml-2" />
                  شاهد إعلان (+3 نقاط)
                </Button>
                <p className="text-xs text-gray-500">
                  مدة الإعلان: 30 ثانية
                </p>
              </div>
            ) : (
              <div className="text-center">
                <Clock className="h-8 w-8 text-gray-400 mx-auto mb-4" />
                <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                  انتظر قليلاً
                </p>
                <Badge variant="outline">
                  {formatTime(adStatus.cooldownRemaining)}
                </Badge>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* طرق أخرى لكسب النقاط */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
            <Gift className="h-6 w-6 text-blue-500" />
            <span>طرق أخرى لكسب النقاط</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center space-x-3 rtl:space-x-reverse p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="p-2 bg-blue-100 dark:bg-blue-800 rounded-lg">
                <RefreshCw className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-medium">بوت Discord</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  استخدم أوامر البوت لكسب نقاط إضافية
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 rtl:space-x-reverse p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="p-2 bg-green-100 dark:bg-green-800 rounded-lg">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-medium">المهام اليومية</h3>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  قريباً - مهام يومية لكسب نقاط إضافية
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* تاريخ النقاط */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
            <History className="h-6 w-6 text-gray-500" />
            <span>تاريخ النقاط</span>
          </CardTitle>
          <CardDescription>
            آخر العمليات على نقاطك
          </CardDescription>
        </CardHeader>
        <CardContent>
          {pointsHistory.length === 0 ? (
            <div className="text-center py-8">
              <History className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-300">
                لا توجد عمليات بعد
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {pointsHistory.slice(0, 10).map((entry, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    {getActionIcon(entry.action)}
                    <div>
                      <p className="font-medium">
                        {getActionText(entry.action)}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        {new Date(entry.created_at).toLocaleString('ar-SA')}
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className={`font-bold ${
                      entry.points_change > 0 
                        ? 'text-green-600' 
                        : 'text-red-600'
                    }`}>
                      {entry.points_change > 0 ? '+' : ''}
                      {entry.points_change}
                    </p>
                    <p className="text-sm text-gray-500">
                      الرصيد: {entry.balance_after}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default Points

