import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Users,
  Server,
  CreditCard,
  Activity,
  TrendingUp,
  TrendingDown,
  Shield,
  Ban,
  UserCheck,
  Coins,
  Play,
  Square,
  Trash2,
  Eye,
  Search,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Loader2,
  BarChart3,
  PieChart,
  Settings,
  Database,
  Container
} from 'lucide-react'

const Admin = () => {
  const [user, setUser] = useState(null)
  const [stats, setStats] = useState(null)
  const [users, setUsers] = useState([])
  const [bots, setBots] = useState([])
  const [subscriptions, setSubscriptions] = useState([])
  const [activityLogs, setActivityLogs] = useState([])
  const [systemInfo, setSystemInfo] = useState(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('dashboard')
  const [searchTerm, setSearchTerm] = useState('')

  // Modals
  const [showPointsModal, setShowPointsModal] = useState(false)
  const [selectedUser, setSelectedUser] = useState(null)
  const [pointsAction, setPointsAction] = useState('add')
  const [pointsAmount, setPointsAmount] = useState('')
  const [pointsReason, setPointsReason] = useState('')

  useEffect(() => {
    checkAdminAccess()
  }, [])

  useEffect(() => {
    if (user && user.is_admin) {
      fetchAdminData()
    }
  }, [user, activeTab])

  const checkAdminAccess = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) {
        setLoading(false)
        return
      }

      const response = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      })

      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
      }
    } catch (error) {
      console.error('Error checking admin access:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchAdminData = async () => {
    const token = localStorage.getItem('token')
    if (!token) return

    try {
      // جلب الإحصائيات
      if (activeTab === 'dashboard') {
        const statsResponse = await fetch('/api/admin/stats', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        if (statsResponse.ok) {
          const statsData = await statsResponse.json()
          setStats(statsData)
        }

        const systemResponse = await fetch('/api/admin/system-info', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        if (systemResponse.ok) {
          const systemData = await systemResponse.json()
          setSystemInfo(systemData)
        }
      }

      // جلب المستخدمين
      if (activeTab === 'users') {
        const usersResponse = await fetch('/api/admin/users', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        if (usersResponse.ok) {
          const usersData = await usersResponse.json()
          setUsers(usersData.users || [])
        }
      }

      // جلب البوتات
      if (activeTab === 'bots') {
        const botsResponse = await fetch('/api/admin/bots', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        if (botsResponse.ok) {
          const botsData = await botsResponse.json()
          setBots(botsData.bots || [])
        }
      }

      // جلب الاشتراكات
      if (activeTab === 'subscriptions') {
        const subsResponse = await fetch('/api/admin/subscriptions', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        if (subsResponse.ok) {
          const subsData = await subsResponse.json()
          setSubscriptions(subsData.subscriptions || [])
        }
      }

      // جلب سجل الأنشطة
      if (activeTab === 'logs') {
        const logsResponse = await fetch('/api/admin/activity-logs', {
          headers: { 'Authorization': `Bearer ${token}` }
        })
        if (logsResponse.ok) {
          const logsData = await logsResponse.json()
          setActivityLogs(logsData.logs || [])
        }
      }

    } catch (error) {
      console.error('Error fetching admin data:', error)
    }
  }

  const handleUserAction = async (userId, action) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/users/${userId}/${action}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        fetchAdminData()
      } else {
        alert(data.error || `حدث خطأ أثناء ${action}`)
      }
    } catch (error) {
      console.error(`Error ${action} user:`, error)
      alert(`حدث خطأ أثناء ${action}`)
    }
  }

  const handlePointsSubmit = async (e) => {
    e.preventDefault()
    
    if (!selectedUser || !pointsAmount || !pointsReason) {
      alert('يرجى ملء جميع الحقول')
      return
    }

    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/users/${selectedUser.id}/points`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          action: pointsAction,
          amount: parseInt(pointsAmount),
          reason: pointsReason
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        setShowPointsModal(false)
        setSelectedUser(null)
        setPointsAmount('')
        setPointsReason('')
        fetchAdminData()
      } else {
        alert(data.error || 'حدث خطأ أثناء تعديل النقاط')
      }
    } catch (error) {
      console.error('Error managing points:', error)
      alert('حدث خطأ أثناء تعديل النقاط')
    }
  }

  const handleBotAction = async (botId, action) => {
    try {
      const token = localStorage.getItem('token')
      const response = await fetch(`/api/admin/bots/${botId}/${action}`, {
        method: action === 'delete' ? 'DELETE' : 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        fetchAdminData()
      } else {
        alert(data.error || `حدث خطأ أثناء ${action}`)
      }
    } catch (error) {
      console.error(`Error ${action} bot:`, error)
      alert(`حدث خطأ أثناء ${action}`)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'running': return 'text-green-600 bg-green-100'
      case 'stopped': return 'text-gray-600 bg-gray-100'
      case 'error': return 'text-red-600 bg-red-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  const getStatusText = (status) => {
    switch (status) {
      case 'running': return 'يعمل'
      case 'stopped': return 'متوقف'
      case 'error': return 'خطأ'
      default: return 'غير معروف'
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="mr-2 text-gray-600">جاري التحميل...</span>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <Shield className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">تسجيل الدخول مطلوب</h2>
        <p className="text-gray-600 mb-6">يرجى تسجيل الدخول للوصول للوحة المشرف</p>
        <Button asChild>
          <a href="/api/auth/login">تسجيل الدخول بـ Discord</a>
        </Button>
      </div>
    )
  }

  if (!user.is_admin) {
    return (
      <div className="text-center py-12">
        <Ban className="h-16 w-16 text-red-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">غير مصرح</h2>
        <p className="text-gray-600 mb-6">ليس لديك صلاحيات للوصول لهذه الصفحة</p>
        <Button asChild>
          <a href="/">العودة للرئيسية</a>
        </Button>
      </div>
    )
  }

  const tabs = [
    { id: 'dashboard', name: 'لوحة التحكم', icon: BarChart3 },
    { id: 'users', name: 'المستخدمين', icon: Users },
    { id: 'bots', name: 'البوتات', icon: Server },
    { id: 'subscriptions', name: 'الاشتراكات', icon: CreditCard },
    { id: 'logs', name: 'سجل الأنشطة', icon: Activity },
  ]

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg p-6 text-white">
        <div className="flex items-center space-x-4 rtl:space-x-reverse">
          <div className="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
            <Shield className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">لوحة تحكم المشرف</h1>
            <p className="text-purple-100">إدارة شاملة للمنصة</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8 rtl:space-x-reverse">
          {tabs.map((tab) => {
            const Icon = tab.icon
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 rtl:space-x-reverse py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.name}</span>
              </button>
            )
          })}
        </nav>
      </div>

      {/* Dashboard Tab */}
      {activeTab === 'dashboard' && stats && (
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">إجمالي المستخدمين</CardTitle>
                <Users className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{stats.users.total}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.users.active} نشط، {stats.users.banned} محظور
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">الاشتراكات النشطة</CardTitle>
                <CreditCard className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{stats.subscriptions.active}</div>
                <p className="text-xs text-muted-foreground">
                  من أصل {stats.subscriptions.total} اشتراك
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">البوتات</CardTitle>
                <Server className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">{stats.bots.total}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.bots.running} يعمل، {stats.bots.stopped} متوقف
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">الإيرادات الشهرية</CardTitle>
                <TrendingUp className="h-4 w-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">{stats.points.monthly_revenue}</div>
                <p className="text-xs text-muted-foreground">نقطة هذا الشهر</p>
              </CardContent>
            </Card>
          </div>

          {/* System Status */}
          {systemInfo && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
                  <Settings className="h-5 w-5" />
                  <span>حالة النظام</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <Database className="h-8 w-8 text-green-600" />
                    <div>
                      <div className="font-medium">قاعدة البيانات</div>
                      <div className="text-sm text-green-600">متصلة</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <Container className={`h-8 w-8 ${systemInfo.docker_available ? 'text-green-600' : 'text-red-600'}`} />
                    <div>
                      <div className="font-medium">Docker</div>
                      <div className={`text-sm ${systemInfo.docker_available ? 'text-green-600' : 'text-red-600'}`}>
                        {systemInfo.docker_available ? 'متاح' : 'غير متاح'}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <Server className="h-8 w-8 text-blue-600" />
                    <div>
                      <div className="font-medium">الحاويات</div>
                      <div className="text-sm text-blue-600">
                        {systemInfo.running_containers}/{systemInfo.total_containers} تعمل
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Users Tab */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">إدارة المستخدمين</h2>
            <Button onClick={fetchAdminData}>
              <RefreshCw className="h-4 w-4 ml-2" />
              تحديث
            </Button>
          </div>

          <div className="space-y-4">
            {users.map((user) => (
              <Card key={user.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        {user.avatar ? (
                          <img 
                            src={`https://cdn.discordapp.com/avatars/${user.discord_id}/${user.avatar}.png`}
                            alt={user.username}
                            className="w-10 h-10 rounded-full"
                          />
                        ) : (
                          <Users className="h-6 w-6 text-blue-600" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium">{user.username}</div>
                        <div className="text-sm text-gray-600">
                          {user.points} نقطة • {user.total_bots} بوت
                        </div>
                        <div className="text-xs text-gray-500">
                          انضم في {new Date(user.created_at).toLocaleDateString('ar-SA')}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      {user.is_admin && (
                        <Badge className="bg-purple-100 text-purple-800">مشرف</Badge>
                      )}
                      {user.active_subscription && (
                        <Badge className="bg-green-100 text-green-800">مشترك</Badge>
                      )}
                      {user.is_banned && (
                        <Badge className="bg-red-100 text-red-800">محظور</Badge>
                      )}
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedUser(user)
                          setShowPointsModal(true)
                        }}
                      >
                        <Coins className="h-3 w-3 ml-1" />
                        النقاط
                      </Button>
                      
                      {!user.is_admin && (
                        <Button
                          size="sm"
                          variant={user.is_banned ? "default" : "destructive"}
                          onClick={() => handleUserAction(user.id, user.is_banned ? 'unban' : 'ban')}
                        >
                          {user.is_banned ? (
                            <>
                              <UserCheck className="h-3 w-3 ml-1" />
                              إلغاء الحظر
                            </>
                          ) : (
                            <>
                              <Ban className="h-3 w-3 ml-1" />
                              حظر
                            </>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Bots Tab */}
      {activeTab === 'bots' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">إدارة البوتات</h2>
            <Button onClick={fetchAdminData}>
              <RefreshCw className="h-4 w-4 ml-2" />
              تحديث
            </Button>
          </div>

          <div className="space-y-4">
            {bots.map((bot) => (
              <Card key={bot.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <Server className="h-6 w-6 text-purple-600" />
                      </div>
                      <div>
                        <div className="font-medium">{bot.bot_name}</div>
                        <div className="text-sm text-gray-600">
                          {bot.language} • المالك: {bot.user.username}
                        </div>
                        <div className="text-xs text-gray-500">
                          تم الإنشاء في {new Date(bot.created_at).toLocaleDateString('ar-SA')}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <Badge className={getStatusColor(bot.status)}>
                        {getStatusText(bot.status)}
                      </Badge>
                      
                      {bot.status === 'running' && (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleBotAction(bot.id, 'stop')}
                        >
                          <Square className="h-3 w-3 ml-1" />
                          إيقاف
                        </Button>
                      )}
                      
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => {
                          if (confirm(`هل أنت متأكد من حذف البوت "${bot.bot_name}"؟`)) {
                            handleBotAction(bot.id, 'delete')
                          }
                        }}
                      >
                        <Trash2 className="h-3 w-3 ml-1" />
                        حذف
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Subscriptions Tab */}
      {activeTab === 'subscriptions' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">إدارة الاشتراكات</h2>
            <Button onClick={fetchAdminData}>
              <RefreshCw className="h-4 w-4 ml-2" />
              تحديث
            </Button>
          </div>

          <div className="space-y-4">
            {subscriptions.map((sub) => (
              <Card key={sub.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <CreditCard className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium">
                          {sub.plan_type === 'weekly' ? 'اشتراك أسبوعي' : 'اشتراك شهري'}
                        </div>
                        <div className="text-sm text-gray-600">
                          المستخدم: {sub.user.username} • {sub.points_cost} نقطة
                        </div>
                        <div className="text-xs text-gray-500">
                          من {new Date(sub.created_at).toLocaleDateString('ar-SA')} 
                          إلى {new Date(sub.expires_at).toLocaleDateString('ar-SA')}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 rtl:space-x-reverse">
                      <Badge className={sub.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                        {sub.is_active ? 'نشط' : 'منتهي'}
                      </Badge>
                      
                      {sub.auto_renew && (
                        <Badge className="bg-blue-100 text-blue-800">تجديد تلقائي</Badge>
                      )}
                      
                      {sub.is_active && (
                        <span className="text-sm text-gray-600">
                          {sub.days_remaining} يوم متبقي
                        </span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Activity Logs Tab */}
      {activeTab === 'logs' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">سجل الأنشطة</h2>
            <Button onClick={fetchAdminData}>
              <RefreshCw className="h-4 w-4 ml-2" />
              تحديث
            </Button>
          </div>

          <div className="space-y-2">
            {activityLogs.map((log) => (
              <Card key={log.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <Activity className="h-4 w-4 text-blue-600" />
                    <div>
                      <div className="text-sm font-medium">{log.description}</div>
                      <div className="text-xs text-gray-600">
                        {log.user ? `بواسطة: ${log.user.username}` : 'النظام'} • 
                        {new Date(log.created_at).toLocaleString('ar-SA')}
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline">{log.action}</Badge>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Points Management Modal */}
      {showPointsModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">
              إدارة نقاط {selectedUser.username}
            </h3>
            <form onSubmit={handlePointsSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  نوع العملية
                </label>
                <select
                  value={pointsAction}
                  onChange={(e) => setPointsAction(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="add">إضافة نقاط</option>
                  <option value="subtract">خصم نقاط</option>
                  <option value="set">تعيين الرصيد</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  المبلغ
                </label>
                <input
                  type="number"
                  value={pointsAmount}
                  onChange={(e) => setPointsAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="عدد النقاط"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  السبب
                </label>
                <input
                  type="text"
                  value={pointsReason}
                  onChange={(e) => setPointsReason(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="سبب التعديل"
                  required
                />
              </div>
              
              <div className="flex space-x-2 rtl:space-x-reverse">
                <Button type="submit">
                  حفظ
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowPointsModal(false)
                    setSelectedUser(null)
                    setPointsAmount('')
                    setPointsReason('')
                  }}
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default Admin

