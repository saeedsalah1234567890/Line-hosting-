import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  CreditCard, 
  Clock, 
  CheckCircle, 
  XCircle,
  RefreshCw,
  Star,
  Coins,
  Calendar,
  Settings,
  AlertTriangle,
  Loader2
} from 'lucide-react'

const Subscriptions = () => {
  const [user, setUser] = useState(null)
  const [plans, setPlans] = useState([])
  const [currentSubscription, setCurrentSubscription] = useState(null)
  const [subscriptionHistory, setSubscriptionHistory] = useState([])
  const [loading, setLoading] = useState(true)
  const [subscribing, setSubscribing] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState(null)

  useEffect(() => {
    fetchUserInfo()
    fetchPlans()
    fetchSubscriptionStatus()
    fetchSubscriptionHistory()
  }, [])

  const fetchUserInfo = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const userData = await response.json()
        setUser(userData)
      }
    } catch (error) {
      console.error('Error fetching user info:', error)
    }
  }

  const fetchPlans = async () => {
    try {
      const response = await fetch('/api/subscription/plans')
      if (response.ok) {
        const data = await response.json()
        setPlans(data.plans || [])
      }
    } catch (error) {
      console.error('Error fetching plans:', error)
    }
  }

  const fetchSubscriptionStatus = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/subscription/status', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setCurrentSubscription(data.hasActiveSubscription ? data.subscription : null)
      }
    } catch (error) {
      console.error('Error fetching subscription status:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchSubscriptionHistory = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/subscription/history', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setSubscriptionHistory(data)
      }
    } catch (error) {
      console.error('Error fetching subscription history:', error)
    }
  }

  const handleSubscribe = async (planType) => {
    if (!user) {
      alert('يرجى تسجيل الدخول أولاً')
      return
    }

    setSubscribing(true)
    setSelectedPlan(planType)

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/subscription/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          plan_type: planType,
          auto_renew: true
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        await fetchUserInfo()
        await fetchSubscriptionStatus()
        await fetchSubscriptionHistory()
      } else {
        alert(data.error || 'حدث خطأ أثناء الاشتراك')
      }
    } catch (error) {
      console.error('Error subscribing:', error)
      alert('حدث خطأ أثناء الاشتراك')
    } finally {
      setSubscribing(false)
      setSelectedPlan(null)
    }
  }

  const handleRenew = async () => {
    if (!currentSubscription) return

    setSubscribing(true)

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/subscription/renew', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        await fetchUserInfo()
        await fetchSubscriptionStatus()
        await fetchSubscriptionHistory()
      } else {
        alert(data.error || 'حدث خطأ أثناء التجديد')
      }
    } catch (error) {
      console.error('Error renewing:', error)
      alert('حدث خطأ أثناء التجديد')
    } finally {
      setSubscribing(false)
    }
  }

  const handleToggleAutoRenew = async () => {
    if (!currentSubscription) return

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/subscription/toggle-auto-renew', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        await fetchSubscriptionStatus()
      } else {
        alert(data.error || 'حدث خطأ أثناء تحديث الإعدادات')
      }
    } catch (error) {
      console.error('Error toggling auto-renew:', error)
      alert('حدث خطأ أثناء تحديث الإعدادات')
    }
  }

  const handleCancelSubscription = async () => {
    if (!currentSubscription) return

    if (!confirm('هل أنت متأكد من إلغاء الاشتراك؟ ستفقد إمكانية الوصول لاستضافة البوت عند انتهاء الفترة الحالية.')) {
      return
    }

    try {
      const token = localStorage.getItem('token')
      const response = await fetch('/api/subscription/cancel', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message)
        await fetchSubscriptionStatus()
        await fetchSubscriptionHistory()
      } else {
        alert(data.error || 'حدث خطأ أثناء إلغاء الاشتراك')
      }
    } catch (error) {
      console.error('Error cancelling subscription:', error)
      alert('حدث خطأ أثناء إلغاء الاشتراك')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <span className="mr-2 text-gray-600">جاري التحميل...</span>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="text-center py-12">
        <CreditCard className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">تسجيل الدخول مطلوب</h2>
        <p className="text-gray-600 mb-6">يرجى تسجيل الدخول لعرض خطط الاشتراك</p>
        <Button asChild>
          <a href="/api/auth/login">تسجيل الدخول بـ Discord</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">خطط الاشتراك</h1>
        <p className="text-gray-600">اختر الخطة المناسبة لك واستمتع باستضافة البوت الخاص بك</p>
      </div>

      {/* Current Subscription Status */}
      {currentSubscription && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <CardTitle className="text-green-800">اشتراكك النشط</CardTitle>
              </div>
              <Badge variant="default" className="bg-green-600">
                نشط
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{currentSubscription.plan_name}</div>
                <div className="text-sm text-gray-600">نوع الاشتراك</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">{currentSubscription.days_remaining}</div>
                <div className="text-sm text-gray-600">يوم متبقي</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {new Date(currentSubscription.expires_at).toLocaleDateString('ar-SA')}
                </div>
                <div className="text-sm text-gray-600">تاريخ الانتهاء</div>
              </div>
            </div>

            {currentSubscription.is_expiring_soon && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <span className="text-yellow-800 text-sm">
                    اشتراكك ينتهي قريباً! قم بالتجديد لتجنب انقطاع الخدمة.
                  </span>
                </div>
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              <Button onClick={handleRenew} disabled={subscribing}>
                {subscribing ? (
                  <Loader2 className="h-4 w-4 animate-spin ml-2" />
                ) : (
                  <RefreshCw className="h-4 w-4 ml-2" />
                )}
                تجديد الاشتراك
              </Button>
              
              <Button 
                variant="outline" 
                onClick={handleToggleAutoRenew}
                className={currentSubscription.auto_renew ? 'border-green-500 text-green-700' : 'border-gray-300'}
              >
                <Settings className="h-4 w-4 ml-2" />
                {currentSubscription.auto_renew ? 'إلغاء التجديد التلقائي' : 'تفعيل التجديد التلقائي'}
              </Button>
              
              <Button variant="destructive" onClick={handleCancelSubscription}>
                <XCircle className="h-4 w-4 ml-2" />
                إلغاء الاشتراك
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Subscription Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {plans.map((plan) => (
          <Card 
            key={plan.id} 
            className={`relative ${plan.popular ? 'border-blue-500 shadow-lg' : 'border-gray-200'}`}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-blue-600 text-white px-3 py-1">
                  <Star className="h-3 w-3 ml-1" />
                  الأكثر شعبية
                </Badge>
              </div>
            )}
            
            <CardHeader className="text-center">
              <CardTitle className="text-xl">{plan.name}</CardTitle>
              <div className="text-3xl font-bold text-blue-600">
                {plan.points_cost}
                <span className="text-lg text-gray-600 font-normal"> نقطة</span>
              </div>
              <CardDescription>
                لمدة {plan.duration_days} أيام
                {plan.savings && (
                  <div className="text-green-600 font-medium mt-1">{plan.savings}</div>
                )}
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <ul className="space-y-2 mb-6">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center space-x-2 rtl:space-x-reverse">
                    <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                    <span className="text-sm text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                className="w-full" 
                onClick={() => handleSubscribe(plan.id)}
                disabled={subscribing || (currentSubscription && currentSubscription.plan_type === plan.id)}
                variant={plan.popular ? 'default' : 'outline'}
              >
                {subscribing && selectedPlan === plan.id ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin ml-2" />
                    جاري الاشتراك...
                  </>
                ) : currentSubscription && currentSubscription.plan_type === plan.id ? (
                  <>
                    <CheckCircle className="h-4 w-4 ml-2" />
                    مشترك حالياً
                  </>
                ) : (
                  <>
                    <CreditCard className="h-4 w-4 ml-2" />
                    اشترك الآن
                  </>
                )}
              </Button>
              
              {user && user.points < plan.points_cost && (
                <p className="text-red-600 text-sm mt-2 text-center">
                  تحتاج {plan.points_cost - user.points} نقطة إضافية
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Points Balance */}
      <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <div className="bg-yellow-100 p-3 rounded-full">
                <Coins className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">رصيدك الحالي</h3>
                <p className="text-2xl font-bold text-yellow-600">{user?.points || 0} نقطة</p>
              </div>
            </div>
            <Button variant="outline" asChild>
              <a href="/points">
                <Coins className="h-4 w-4 ml-2" />
                كسب المزيد من النقاط
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Subscription History */}
      {subscriptionHistory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse">
              <Calendar className="h-5 w-5" />
              <span>تاريخ الاشتراكات</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {subscriptionHistory.map((sub) => (
                <div key={sub.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <div className={`p-2 rounded-full ${
                      sub.status === 'نشط' ? 'bg-green-100' : 
                      sub.status === 'ملغي' ? 'bg-red-100' : 'bg-gray-100'
                    }`}>
                      {sub.status === 'نشط' ? (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      ) : sub.status === 'ملغي' ? (
                        <XCircle className="h-4 w-4 text-red-600" />
                      ) : (
                        <Clock className="h-4 w-4 text-gray-600" />
                      )}
                    </div>
                    <div>
                      <div className="font-medium">{sub.plan_name}</div>
                      <div className="text-sm text-gray-600">
                        {new Date(sub.created_at).toLocaleDateString('ar-SA')} - 
                        {new Date(sub.expires_at).toLocaleDateString('ar-SA')}
                      </div>
                    </div>
                  </div>
                  <div className="text-left">
                    <Badge variant={
                      sub.status === 'نشط' ? 'default' : 
                      sub.status === 'ملغي' ? 'destructive' : 'secondary'
                    }>
                      {sub.status}
                    </Badge>
                    <div className="text-sm text-gray-600 mt-1">
                      {sub.points_cost} نقطة
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default Subscriptions

