import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Dashboard from './pages/Dashboard'
import Points from './pages/Points'
import Subscriptions from './pages/Subscriptions'
import Hosting from './pages/Hosting'
import Admin from './pages/Admin'
import AuthSuccess from './pages/AuthSuccess'
import './App.css'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/points" element={<Points />} />
          <Route path="/subscriptions" element={<Subscriptions />} />
          <Route path="/hosting" element={<Hosting />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/auth/success" element={<AuthSuccess />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App

